function S4 = S4fun_pm4_nascentRNA_1(bb4)
%%%% ��С����

global  t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24 m second fanodata %%����

T=[t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24];
b4=[exp(bb4(1)) exp(bb4(2)) exp(bb4(3)) 1+4999./(exp(bb4(4))+1)];

lam_1 = 0.1;
lam_2 = b4(1);
q_2 = b4(2);
q_1 = 1 - q_2;
k_10 = b4(3);
r = b4(4);
T1=1;

Delta=(lam_1+lam_2+k_10)^2-4*((lam_1*q_2+lam_2*q_1)*k_10+lam_1*lam_2);
alpha=(1/2)*(lam_1+lam_2+k_10+sqrt(Delta));
beta=(1/2)*(lam_1+lam_2+k_10-sqrt(Delta));
A1=alpha+beta;
A2=alpha*beta;
N=lam_1*lam_2/(A2);
P=(lam_1-alpha)*(lam_2-alpha)/(alpha^2*(beta-alpha));
Q=(lam_1-beta)*(lam_2-beta)/(beta^2*(alpha-beta));
m1=-P-Q;

for t=1:1:length(T)
    if T(t)<=T1
        xmean(t)=r*(m1+N*T(t)+P*exp(-alpha*T(t))+Q*exp(-beta*T(t)));
        u2(t)=2*r^2*(m1*N*T(t)+m1*P*(exp(-alpha*T(t))-1)+m1*Q*(exp(-beta*T(t))-1)+(1/2)*N^2*T(t)^2-N*P*(T(t)*exp(-alpha*T(t))+(1/alpha)*(exp(-alpha*T(t))-1))+N*P*T(t)*(exp(-alpha*T(t))-1)+N*Q*T(t)*(exp(-beta*T(t))-1)-N*Q*(T(t)*exp(-beta*T(t))+(1/beta)*(exp(-beta*T(t))-1))+(1/alpha)*P*N*(1-exp(-alpha*T(t)))-P^2*alpha*T(t)*exp(-alpha*T(t))-(1/(alpha-beta))*P*Q*beta*(exp(-beta*T(t))-exp(-alpha*T(t)))+(1/beta)*N*Q*(1-exp(-beta*T(t)))-Q^2*beta*T(t)*exp(-beta*T(t))-(1/(beta-alpha))*P*Q*alpha*(exp(-alpha*T(t))-exp(-beta*T(t))))+xmean(t);
        % ���׾�
        xfano(t)=(u2(t)-xmean(t)^2)/xmean(t);
       else
        xmean(t)=r*(N*T1+P*exp(-alpha*T(t))*(1-exp(alpha*T1))+Q*exp(-beta*T(t))*(1-exp(beta*T1)));
        u2(t)=2*r^2*(m1*N*T1+m1*P*exp(-alpha*T(t))*(1-exp(alpha*T1))+m1*Q*exp(-beta*T(t))*(1-exp(beta*T1))+(1/2)*N^2*T1^2-N*P*exp(-alpha*T(t))*(T1*exp(alpha*T1)+(1/alpha)*(1-exp(alpha*T1)))-N*Q*exp(-beta*T(t))*(T1*exp(beta*T1)+(1/beta)*(1-exp(beta*T1)))+(1/alpha)*P*N*(1-exp(-alpha*T1))-P^2*alpha*T1*exp(-alpha*T(t))-(1/(alpha-beta))*P*Q*beta*(1-exp(-(alpha-beta)*T1))*exp(-beta*T(t))+(1/beta)*N*Q*(1-exp(-beta*T1))-Q^2*beta*T1*exp(-beta*T(t))-(1/(beta-alpha))*P*Q*alpha*(1-exp(-(beta-alpha)*T1))*exp(-alpha*T(t)))+xmean(t);
        xfano(t)=(u2(t)-xmean(t)^2)/xmean(t);
    end
end
b4;


%% ��ֵ����

Smean = 0;
for i = 1:length(m)
    Smean = Smean+(xmean(i)-m(i)).^2./m(i).^2;
end


Su2 = 0;
for i = 1:length(second)
    Su2 = Su2+(u2(i)-second(i)).^2./second(i).^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano+(xfano(i)-fanodata(i)).^2./fanodata(i).^2;
end

S4=Smean+Su2+Sfano;

end