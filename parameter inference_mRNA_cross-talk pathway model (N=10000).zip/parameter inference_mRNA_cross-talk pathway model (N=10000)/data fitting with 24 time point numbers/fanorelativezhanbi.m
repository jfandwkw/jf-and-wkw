% ==== 预设参数 ====
T = 1;
numGroup = 24;                 % 共24个Excel文件
numCol = 100;                  % 每个文件前100列
delta = 1;                     % 降解率参数

% ==== 读取拟合参数 ====
data1 = xlsread('twostate_fitmethod_N10000_Smin.xlsx');

% ==== 初始化：每列的相对误差集合 ====
rel_error_matrix = NaN(numGroup, numCol);  % 行：组；列：列号

% ==== 主循环 ====
for j = 1:numGroup
    filename = sprintf('N10000_twostate_t%d.xlsx', j);
    datatemp = xlsread(filename);

    for k = 1:numCol
        TT = datatemp(10, k);
        fano_exp = datatemp(9, k);

        if isnan(TT) || isnan(fano_exp)
            continue;
        end

        % Get parameters for current group
        k_01 = data1(j, 5); % kon
        k_10 = data1(j, 6); % koff
        r = data1(j, 7);    % production rate
        
        % Calculate theoretical Fano factor
        % Mean expression
        xmean = k_01*r/((k_01+k_10)*delta) - ...
                k_01*r/((k_01+k_10)*(delta-k_01-k_10))*exp(-(k_01+k_10)*TT) + ...
                k_01*r/(delta*(delta-k_01-k_10))*exp(-delta*TT);
        
        % Second moment
        term1 = (r*delta*(delta+k_01+k_10)+r^2*(delta+k_01))*k_01/(delta^2*(k_01+k_10)*(delta+k_01+k_10));
        term2 = -(r*(2*delta^2-k_01*delta-k_10*delta+2*r*delta-2*r*k_10))*k_01/...
                (delta*(k_01+k_10)*(delta-(k_01+k_10))*(2*delta-(k_01+k_10)))*exp(-(k_01+k_10)*TT);
        term3 = -(k_01*r*delta*(k_01+k_10)+2*k_01^2*r^2)/(delta^2*(k_01+k_10)*(k_01+k_10-delta))*exp(-delta*TT);
        term4 = k_01*r^2*(k_01-delta)/(delta^2*(k_01+k_10-2*delta)*(k_01+k_10-delta))*exp(-2*delta*TT);
        term5 = 2*r^2*k_01*k_10/(delta*(k_01+k_10)*(delta+k_01+k_10)*(delta-k_01-k_10))*exp(-(delta+k_01+k_10)*TT);
        
        u2 = term1 + term2 + term3 + term4 + term5;
        
        % Fano factor
        fano_calc = (u2 - xmean^2)/xmean;
        
        % Calculate relative error (absolute value)
        if ~isnan(fano_calc) && fano_calc ~= 0  % Avoid division by zero and NaN values
            rel_error = (fano_exp - fano_calc) / fano_calc;
            rel_error_matrix(j, k) = rel_error;
        end
    end
end

% ==== 每列平均相对误差 ====
mean_rel_error_col = nanmean(rel_error_matrix, 1);  % Average across groups for each column

% ==== 过滤掉NaN值 ====
valid_cols = ~isnan(mean_rel_error_col);
col_id = find(valid_cols)';
mean_rel_error_valid = mean_rel_error_col(valid_cols)';

% ==== 计算平均相对误差 >= 1 的占比 ====
num_large_error = sum(mean_rel_error_valid >= 1);
ratio_large_error = num_large_error / length(mean_rel_error_valid);

% ==== 输出 ====
fprintf('2状态拟合2路径 满足平均相对误差 >= 1 的列数为 %d，共 %d 有效列。\n', num_large_error, length(mean_rel_error_valid));
fprintf('占比为：%.2f%%\n', ratio_large_error * 100);

% ==== 保存到 Excel ====
if ~isempty(col_id)
    output_table = table(col_id, mean_rel_error_valid, 'VariableNames', {'Column', 'Mean_Rel_Error'});
    writetable(output_table, 'Column_Mean_RelError.xlsx');
else
    warning('没有有效数据可保存到Excel文件');
end