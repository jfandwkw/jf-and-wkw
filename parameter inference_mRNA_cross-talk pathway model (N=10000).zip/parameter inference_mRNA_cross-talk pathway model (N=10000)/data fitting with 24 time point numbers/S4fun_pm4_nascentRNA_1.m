function S4 = S4fun_pm4_nascentRNA_1(bb4)
%%%% Main function

global t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24 m second fanodata %% parameters

T = [t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24];
b4 = [exp(bb4(1)), exp(bb4(2)), exp(bb4(3)), 1+4999./(exp(bb4(4))+1)];

% Parameter definitions
    lam_1 = 0.1;
    lam_2 = b4(1);
    q_2 = b4(2);
    q_1 = 1 - q_2;
    k10 = b4(3);
    nu = b4(4);
    delta = 1;  % 根据您之前的定义
    
    % 计算中间变量
    Delta = (lam_1 + lam_2 + k10)^2 - 4*((lam_1*q_2 + lam_2*q_1)*k10 + lam_1*lam_2);
    alpha = 0.5*(lam_1 + lam_2 + k10 + sqrt(Delta));
    beta = 0.5*(lam_1 + lam_2 + k10 - sqrt(Delta));
    
     
    for t = 1:1:length(T);
    % 计算m(t)的各个部分
    term1 = (lam_1 * lam_2 * nu) / (alpha * beta * delta);
    
    numerator2 = lam_1 * lam_2 * nu - alpha * nu * (q_1 * lam_1 + q_2 * lam_2);
    denominator2 = alpha * (beta - alpha) * (delta - alpha);
    term2 = (numerator2 / denominator2) * exp(-alpha * t);
    
    numerator3 = lam_1 * lam_2 * nu - beta * nu * (q_1 * lam_1 + q_2 * lam_2);
    denominator3 = beta * (alpha - beta) * (delta - beta);
    term3 = (numerator3 / denominator3) * exp(-beta * t);
    
    numerator4 = lam_1 * lam_2 * nu - delta * nu * (q_1 * lam_1 + q_2 * lam_2);
    denominator4 = delta * (alpha - delta) * (beta - delta);
    term4 = (numerator4 / denominator4) * exp(-delta * t);
    
    % 组合最终结果
    xmean(t) = term1 - term2 - term3 - term4;


   % 辅助函数：计算 lambda1*lambda2 - x*(q1*lambda1 + q2*lambda2)
    f = @(x) lam_1*lam_2 - x*(q_1*lam_1 + q_2*lam_2);
    
    % 计算u2(t)各系数
    % b0
    numerator_b0 = nu*delta*(delta+alpha)*(delta+beta) + nu^2*(delta+lam_1)*(delta+lam_2);
    denominator_b0 = alpha*beta*delta^2*(delta+alpha)*(delta+beta);
    b0 = (numerator_b0 / denominator_b0) * lam_1*lam_2;
    
    % b_alpha
    numerator_balpha = nu*delta*(2*delta-alpha)*(delta+beta-alpha) + 2*nu^2*(delta+lam_1-alpha)*(delta+lam_2-alpha);
    denominator_balpha = alpha*delta*(beta-alpha)*(delta-alpha)*(2*delta-alpha)*(delta+beta-alpha);
    balpha = -(numerator_balpha / denominator_balpha) * f(alpha);
    
    % b_beta
    numerator_bbeta = nu*delta*(2*delta-beta)*(delta+alpha-beta) + 2*nu^2*(delta+lam_1-beta)*(delta+lam_2-beta);
    denominator_bbeta = beta*delta*(alpha-beta)*(delta-beta)*(2*delta-beta)*(delta+alpha-beta);
    bbeta = -(numerator_bbeta / denominator_bbeta) * f(beta);
    
    % b_delta
    numerator_bdelta = nu*delta*alpha*beta + 2*nu^2*lam_1*lam_2;
    denominator_bdelta = alpha*beta*delta^2*(alpha-delta)*(beta-delta);
    bdelta = -(numerator_bdelta / denominator_bdelta) * f(delta);
    
    % b_2delta
    numerator_b2delta = nu^2*(lam_1-delta)*(lam_2-delta);
    denominator_b2delta = delta^2*(alpha-2*delta)*(beta-2*delta)*(alpha-delta)*(beta-delta);
    b2delta = (numerator_b2delta / denominator_b2delta) * f(2*delta);
    
    % b_delta_alpha
    numerator_bda = 2*nu^2*(lam_1-alpha)*(lam_2-alpha);
    denominator_bda = delta*alpha*(delta+alpha)*(beta-delta-alpha)*(delta-alpha)*(beta-alpha);
    bdelta_alpha = -(numerator_bda / denominator_bda) * f(delta+alpha);
    
    % b_delta_beta
    numerator_bdb = 2*nu^2*(lam_1-beta)*(lam_2-beta);
    denominator_bdb = delta*beta*(delta+beta)*(alpha-delta-beta)*(delta-beta)*(alpha-beta);
    bdelta_beta = -(numerator_bdb / denominator_bdb) * f(delta+beta);
    
    % 组合最终结果
    u2(t) = b0 + ...
            balpha * exp(-alpha * t) + ...
            bbeta * exp(-beta * t) + ...
            bdelta * exp(-delta * t) + ...
            b2delta * exp(-2 * delta * t) + ...
            bdelta_alpha * exp(-(delta + alpha) * t) + ...
            bdelta_beta * exp(-(delta + beta) * t);
     
    xfano(t)=(u2(t)-(xmean(t)).^2)./xmean(t);
end
b4;


%% Calculate objective function
Smean = 0;
for i = 1:length(m)
    Smean = Smean + (xmean(i)-m(i))^2/m(i)^2;
end

Su2 = 0;
for i = 1:length(second)
    Su2 = Su2 + (u2(i)-second(i))^2/second(i)^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano + (xfano(i)-fanodata(i))^2/fanodata(i)^2;
end

S4 = Smean + Su2 + Sfano;
end
