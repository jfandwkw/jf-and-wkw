% ==== 预设参数 ====
T = 1;                              % 常数 T 设置为1
numGroup = 24;                      % 共24个Excel文件
numCol = 100;                       % 每个文件前100列

% ==== 读取拟合参数 ====
data1 = xlsread('twostate_fitmethod_N10000_Smin.xlsx');

% ==== 初始化：每列的相对误差集合 ====
rel_error_matrix = NaN(numGroup, numCol);  % 行：组；列：列号

% ==== 主循环 ====
for j = 3:3:numGroup
    filename = sprintf('N10000_twostate_t%d.xlsx', j);
    datatemp = xlsread(filename);

    A2 = data1(j, 5);
    B2 = data1(j, 6);
    C2 = data1(j, 7);

    kon = A2;
    koff = B2;
    v = C2;
    delta = 1;

    for k = 1:numCol
        TT = datatemp(7, k); % 时间
        fano_exp = datatemp(6, k); % fano

        if isnan(TT) || isnan(fano_exp)
            continue;
        end

        t = 0:0.001:TT;  % 时间数组
        M2_est = zeros(size(t));
        Var2 = zeros(size(t));
        Fano2 = zeros(size(t));

        for i = 1:length(t)
            % 计算 M2_est、Var2 和 Fano2
            M2_est(i) = kon * v / ((kon + koff) * delta) - kon * v / ((kon + koff) * (delta - kon - koff)) * exp(-(kon + koff) * t(i)) + kon * v / (delta * (delta - kon - koff)) * exp(-delta * t(i));

            Var2(i) = (v * delta * (delta + kon + koff) + v^2 * (delta + kon)) * kon / (delta^2 * (kon + koff) * (delta + kon + koff)) ...
                    - (v * (2 * delta^2 - kon * delta - koff * delta + 2 * v * delta - 2 * v * koff)) * kon / (delta * (kon + koff) * (delta - (kon + koff)) * (2 * delta - (kon + koff))) * exp(-(kon + koff) * t(i)) ...
                    - (kon * v * delta * (kon + koff) + 2 * kon^2 * v^2) / (delta^2 * (kon + koff) * (kon + koff - delta)) * exp(-delta * t(i)) ...
                    + kon * v^2 * (kon - delta) / (delta^2 * (kon + koff - 2 * delta) * (kon + koff - delta)) * exp(-2 * delta * t(i)) ...
                    + 2 * v^2 * kon * koff / (delta * (kon + koff) * (delta + kon + koff) * (delta - kon - koff)) * exp(-(delta + kon + koff) * t(i));

            Fano2(i) = (Var2(i) - M2_est(i)^2) / M2_est(i);    
        end

        [~, idx_TT] = min(abs(t - TT)); % 查找最接近时间点
        fano_calc = Fano2(idx_TT);      % 计算 Fano 值
        rel_error = (fano_exp - fano_calc) / fano_calc;  % 相对误差

        rel_error_matrix(j, k) = rel_error;  % 存储误差
    end
end

% ==== 每列平均相对误差 ====
mean_rel_error_col = nanmean(rel_error_matrix, 1);  % 计算每列的平均相对误差

% ==== 计算平均相对误差 <1 的占比 ====
num_large_error = sum(mean_rel_error_col < 1);  % 找到绝对值小于1的误差个数
ratio_large_error = num_large_error / numCol;        % 占比

% ==== 输出 ====
fprintf('2状态拟合 满足平均相对误差 <1 的列数为 %d，共 %d 列。\n', num_large_error, numCol);
fprintf('占比为：%.2f%%\n', ratio_large_error * 100);

% ==== 保存到 Excel ====
col_id = (1:numCol)';  % 列号
output_table = table(col_id, mean_rel_error_col', 'VariableNames', {'Column', 'Mean_Rel_Error'});
writetable(output_table, 'Column_Mean_RelError.xlsx');
