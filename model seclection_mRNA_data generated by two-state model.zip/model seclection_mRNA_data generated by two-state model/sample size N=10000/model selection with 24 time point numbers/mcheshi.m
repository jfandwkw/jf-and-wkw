j = 96;         % 第j列数据（用于提取 Excel 中的列）
TT = 6;        % 时间最大值
T = 1;         % 转换时间点
t = 0:0.001:TT;

% 读取拟合参数文件（two-state估计参数）
data1 = xlsread('twostate_fitmethod_N10000_Smin.xlsx');

% 读取真实参数（crosstalking模型参数）
data = xlsread('N10000_twostate_t24.xlsx');

%% -------- 第一组参数（真实参数） --------
kon = data(1, j);
koff = data(2, j);
kb   = data(3, j);
delta = 1;

odefun=@(t,y)[
    koff*y(2)-kon*y(1);
    kon*y(1)-koff*y(2);
    kb*y(2)-delta*y(3);
    -(kon+delta)*y(4)+koff*y(5);
    -(koff+delta)*y(5)+kon*y(4)+kb*y(2);
    -2*delta*y(6)+delta*y(3)+kb*y(2)+2*kb*y(5)
];

y00=[1,0,0,0,0,0];
options=odeset('reltol',1e-6,'abstol',1e-8);
[t1,y1]=ode45(odefun,[0,TT],y00,options);
M1 = y1(:,3);  % Mean from true parameters

%% -------- 第二组参数（估计参数） --------
k_01  = data1(j, 5); %kon
k_10 = data1(j, 6); %koff
r   = data1(j, 7);

odefun=@(t,y)[
    k_10*y(2)-k_01*y(1);
    k_01*y(1)-k_10*y(2);
    r*y(2)-delta*y(3);
    -(k_01+delta)*y(4)+k_10*y(5);
    -(k_10+delta)*y(5)+k_01*y(4)+r*y(2);
    -2*delta*y(6)+delta*y(3)+r*y(2)+2*r*y(5)
];

y00=[1,0,0,0,0,0];
options=odeset('reltol',1e-6,'abstol',1e-8);
[t2,y2]=ode45(odefun,[0,TT],y00,options);
M2 = y2(:,3);  % Mean from estimated parameters

%% -------- 读取实验数据点（用于叠加在图上） --------
x = zeros(1, 24);  % 时间（第10行第j列）
y = zeros(1, 24);  % 均值（第7行第j列）
for t_idx = 1:24
    filename = sprintf('N10000_twostate_t%d.xlsx', t_idx);
    data_exp = readmatrix(filename);
    x(t_idx) = data_exp(7, j);  % 时间在第7行
    y(t_idx) = data_exp(4, j);    % 均值在第4行
end

%% -------- 绘图 --------
figure;
plot(t1, M1, 'b-', 'LineWidth', 2); hold on;               % 真实参数模型
plot(t2, M2, 'r--', 'LineWidth', 2);                      % 估计参数模型
plot(x, y, 'ko', 'LineWidth', 1.5, 'MarkerSize', 6);      % 实验数据点

legend('真实参数', '估计参数', '实验数据点', 'Location', 'best');
xlabel('时间 t');
ylabel('Mean');
title(sprintf('crosstalking model 第 %d 组 mean 拟合对比及数据点', j));
grid on;
hold off;