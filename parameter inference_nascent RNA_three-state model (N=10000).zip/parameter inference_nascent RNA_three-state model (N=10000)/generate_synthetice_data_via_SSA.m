function endtest_2_state_nascentRNA

clc;
close all;
clear all;

data2=xlsread('parameter.xlsx');

for zushu = 1:1:100
    tic;  % 计时器
    %% 初始化参数
    clearvars -except zushu data2;

    a2=data2(:,zushu);
    real_para=data2(1:4,zushu); %2状态数据
    % lam_T = real_para(1);

    lam_1 = real_para(1);
    lam_2 = real_para(2);
    % q_1 = real_para(3);
    % q_2 = real_para(4);
    gamma_T = real_para(3);
    nu_T = real_para(4);
    T1 = 1;
    
    k_01 = lam_1;
    k_12 = lam_2;
    k_20 = gamma_T;
    r = nu_T;

    gamma = k_20;
    nu = r;

    str1 = {num2str(lam_1), num2str(lam_2), num2str(gamma), num2str(nu)}';
    %% 时间离散化
    TT = 200;
    H = 200;
    eps = 0.01;
    TP(1) = TT / H;
    for i = 2:H
        TP(i) = TT / H + TP(i - 1);
    end

    %% 理论均值和方差计算
    Delta=(k_01+k_12+k_20)^2-4*((k_01+k_12)*k_20+k_01*k_12);
    alpha=(1/2)*(k_01+k_12+k_20+sqrt(Delta));
    beta=(1/2)*(k_01+k_12+k_20-sqrt(Delta));
    A1=alpha+beta;
    A2=alpha*beta;
    N=k_01*k_12/(A2);
    P=(k_01-alpha)*(k_12-alpha)/(alpha^2*(beta-alpha));
    Q=(k_01-beta)*(k_12-beta)/(beta^2*(alpha-beta));
    m=-P-Q;
    t=0:0.001:200;
    M=zeros(size(t));
    Var=zeros(size(t));
    Fano=zeros(size(t));
    for i=1:length(t)
        if t(i)<=T1
            M1(i)=r*(m+N*t(i)+P*exp(-alpha*t(i))+Q*exp(-beta*t(i)));%mean
            Var(i)=2*r^2*(m*N*t(i)+m*P*(exp(-alpha*t(i))-1)+m*Q*(exp(-beta*t(i))-1)+(1/2)*N^2*t(i)^2-N*P*(t(i)*exp(-alpha*t(i))+(1/alpha)*(exp(-alpha*t(i))-1))+N*P*t(i)*(exp(-alpha*t(i))-1)+N*Q*t(i)*(exp(-beta*t(i))-1)-N*Q*(t(i)*exp(-beta*t(i))+(1/beta)*(exp(-beta*t(i))-1))+(1/alpha)*P*N*(1-exp(-alpha*t(i)))-P^2*alpha*t(i)*exp(-alpha*t(i))-(1/(alpha-beta))*P*Q*beta*(exp(-beta*t(i))-exp(-alpha*t(i)))+(1/beta)*N*Q*(1-exp(-beta*t(i)))-Q^2*beta*t(i)*exp(-beta*t(i))-(1/(beta-alpha))*P*Q*alpha*(exp(-alpha*t(i))-exp(-beta*t(i))))+M1(i)-M1(i)^2;
            %variance
            M2(i)=Var(i)+M1(i)^2;%second moment
            Fano(i)=Var(i)/M1(i);
        else
            M1(i)=r*(N*T1+P*exp(-alpha*t(i))*(1-exp(alpha*T1))+Q*exp(-beta*t(i))*(1-exp(beta*T1)));
            Var(i)=2*r^2*(m*N*T1+m*P*exp(-alpha*t(i))*(1-exp(alpha*T1))+m*Q*exp(-beta*t(i))*(1-exp(beta*T1))+(1/2)*N^2*T1^2-N*P*exp(-alpha*t(i))*(T1*exp(alpha*T1)+(1/alpha)*(1-exp(alpha*T1)))-N*Q*exp(-beta*t(i))*(T1*exp(beta*T1)+(1/beta)*(1-exp(beta*T1)))+(1/alpha)*P*N*(1-exp(-alpha*T1))-P^2*alpha*T1*exp(-alpha*t(i))-(1/(alpha-beta))*P*Q*beta*(1-exp(-(alpha-beta)*T1))*exp(-beta*t(i))+(1/beta)*N*Q*(1-exp(-beta*T1))-Q^2*beta*T1*exp(-beta*t(i))-(1/(beta-alpha))*P*Q*alpha*(1-exp(-(beta-alpha)*T1))*exp(-alpha*t(i)))+M1(i)-M1(i)^2;
            M2(i)=Var(i)+M1(i)^2;%second moment
            Fano(i)=Var(i)/M1(i);
        end
    end

    %% 确定稳定点
    for j = 1:H
        for i = 1:length(t)
            if t(i) >= TP(j)
                break;
            end
            k(j) = i + 1;
        end
    end

    for j = 1:H
        meandata(j) = M1(k(j));
        seconddata(j) = M2(k(j));
    end

    k = H;
    for j = 1:H
        if abs(meandata(H) - meandata(H - j)) / meandata(H) <= eps
            k = k - 1;
        else
            break;
        end
    end
    meantime = k * (TT / H);

    k1 = H;
    for j = 1:H
        if abs(seconddata(H) - seconddata(H - j)) / seconddata(H) < eps
            k1 = k1 - 1;
        else
            break;
        end
    end
    secondtime = k1 * (TT / H);

    tend = max(meantime, secondtime);

    P = 24;
    t_values = round((1:P) * tend / P * 1000) / 1000;

    
    %% 设置 Excel 输出位置
    if zushu <= 26
        location = char(65 + mod(zushu - 1, 100));
    elseif zushu <= 52
        location = char([65 + mod(0, 100), 65 + mod(zushu - 27, 100)]);
    elseif zushu <= 78
        location = char([65 + mod(1, 100), 65 + mod(zushu - 53, 100)]);
    else
        location = char([65 + mod(2, 100), 65 + mod(zushu - 79, 100)]);
    end

    % range1 = [location, '1:', location, '3'];
    range1 = [location, '1:', location, '6'];
   
    filenames = cell(1, P);
    for i = 1:P
        filenames{i} = ['N10000_twostate_t', num2str(i), '.xlsx'];
        xlswrite(filenames{i}, str1, 1, range1);
    end

    %% 模拟 nascent RNA 生产
    N = 10000;
    num = 1000;

    nascent_storage = zeros(P, N);

    for t_idx = 1:P
        t_point = t_values(t_idx);
        for j = 1:N
            store=zeros(num+1,2);
            time=0; %0; 5.5
            initiation=0; %0; 3
            don=1; doff1=0; doff2=0;
            for i=2:num+1
                h=[don doff1 doff2 don];
                c=[k_20 k_01 k_12 r];
                a1=h.*c;
                react=sum(a1);
                rand_num = rand(2,1);
                tau = -log(rand_num(1))/react;
                tauu(i,:) = tau;
                if  rand_num(2)<=k_20*don/react
                    don=0;doff1=1;doff2=0;
                else if rand_num(2)<=(k_20*don+k_01*doff1)/react
                        don=0;doff1=0;doff2=1;
                else if rand_num(2)<=(k_20*don+k_01*doff1+k_12*doff2)/react
                        don=1; doff1=0; doff2=0;
                else
                    initiation=initiation+1;
                    don=1;doff1=0;doff2=0;
                end
                end
                end
                time=time+tau;
                store(i,:)=[initiation time];
            end

            diff = abs(t_point - store(:, 2));
            [~, I] = min(diff);
            if store(I, 2) < t_point
                mRNA = store(I, 1);
            else
                mRNA = store(I - 1, 1);
            end
            if t_point > T1
                % 减去 (t_point - T1) 时的数量
                diff_T1 = abs((t_point - T1) - store(:, 2));
                [~, I_T1] = min(diff_T1);
                if store(I_T1, 2) < (t_point - T1)
                    mRNA_T1 = store(I_T1, 1);
                else
                    mRNA_T1 = store(I_T1 - 1, 1);
                end
                nascent_storage(t_idx, j) = mRNA - mRNA_T1;
            else
                nascent_storage(t_idx, j) = mRNA;
            end
        end
    end

    %% 计算频率、一阶矩和二阶矩和fano
    M = ceil(3 * nu + 1) + 300; % 定义 M
    xdata = zeros(P, M);
    mean_values = zeros(P, 1);
    second_values = zeros(P, 1);

    for t_idx = 1:P
        xdata(t_idx, :) = histcounts(nascent_storage(t_idx, :), 0:M) / N;
        mean_values(t_idx) = sum((0:M - 1) .* xdata(t_idx, :));
        second_values(t_idx) = sum(((0:M - 1).^2) .* xdata(t_idx, :));
        fano_values(t_idx) = (second_values(t_idx) - mean_values(t_idx)^2) /mean_values(t_idx);
    end

    range2 = [location, '5:', location, '8'];
    range3 = [location, '9'];

    for i = 1:P
        str2 = {num2str(mean_values(i)), num2str(second_values(i)), num2str(fano_values(i)), num2str(t_values(i))}';
        xlswrite(filenames{i}, str2, 1, range2);
        xlswrite(filenames{i}, xdata(i, :)', 1, range3);
    end

    disp(['Completed iteration: ', num2str(zushu)]);
    toc
end
end
