function S4 = S4fun_pm4(bb4)
%%%% ��С����


global  t6 t12 t18 t24 m second fanodata
T=[t6 t12 t18 t24];
b4=[exp(bb4(1)) exp(bb4(2)) 1+4999./(exp(bb4(3))+1)];
b4(4)=1;
for t = 1:1:length(T);

xmean(t)=b4(1).*b4(3)./((b4(1)+b4(2)).*b4(4))-b4(1).*b4(3)./((b4(1)+b4(2)).*(b4(4)-b4(1)-b4(2))).*exp(-(b4(1)+b4(2)).*T(t))+b4(1).*b4(3)./(b4(4).*(b4(4)-b4(1)-b4(2))).*exp(-b4(4).*T(t));

u2(t)=(b4(3).*b4(4).*(b4(4)+b4(1)+b4(2))+b4(3).^2.*(b4(4)+b4(1))).*b4(1)./(b4(4).^2.*(b4(1)+b4(2)).*(b4(4)+b4(1)+b4(2)))...
    -(b4(3).*(2*b4(4).^2-b4(1).*b4(4)-b4(2).*b4(4)+2.*b4(3).*b4(4)-2*b4(3).*b4(2))).*b4(1)./(b4(4).*(b4(1)+b4(2)).*(b4(4)-(b4(1)+b4(2))).*(2*b4(4)-(b4(1)+b4(2)))).*exp(-(b4(1)+b4(2)).*T(t))...
    -(b4(1).*b4(3).*b4(4).*(b4(1)+b4(2))+2*b4(1).^2*b4(3).^2)./(b4(4).^2.*(b4(1)+b4(2)).*(b4(1)+b4(2)-b4(4))).*exp(-b4(4).*T(t))...
    +b4(1).*b4(3).^2.*(b4(1)-b4(4))./(b4(4).^2.*(b4(1)+b4(2)-2*b4(4)).*(b4(1)+b4(2)-b4(4))).*exp(-2*b4(4).*T(t))...
    +2.*b4(3).^2.*b4(1).*b4(2)./(b4(4).*(b4(1)+b4(2)).*(b4(4)+b4(1)+b4(2)).*(b4(4)-b4(1)-b4(2))).*exp(-(b4(4)+b4(1)+b4(2)).*T(t));

xfano(t)=(u2(t)-(xmean(t)).^2)./xmean(t);


% bc=b4(1)+b4(2)+(t-1); 
% ac=b4(1)+(t-1); xc=-b4(3);
% yc=2.*ac./(bc-xc+sqrt((xc-bc).^2+4.*ac.*xc)); 
% rc=(yc.^2)./ac+((1-yc).^2)./(bc-ac);
% 
% x1(t) = ((b4(3)).^(t-1)./factorial(t-1)).*(gamma(b4(1)+b4(2)).*gamma(b4(1)+(t-1)))./(gamma(b4(1)).*gamma(b4(1)+b4(2)+(t-1)))...
% .*bc.^(bc-(1/2)).*(rc.^(-1/2)).*((yc./ac).^ac).*(((1-yc)./(bc-ac)).^(bc-ac)).*exp(xc.*yc); 
% 

end
b4;


%% ��ֵ����

Smean = 0;
for i = 1:length(m)
    Smean = Smean+(xmean(i)-m(i)).^2./m(i).^2;
end


Su2 = 0;
for i = 1:length(second)
    Su2 = Su2+(u2(i)-second(i)).^2./second(i).^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano+(xfano(i)-fanodata(i)).^2./fanodata(i)^2;
end

S4=Smean+Su2+Sfano;

end