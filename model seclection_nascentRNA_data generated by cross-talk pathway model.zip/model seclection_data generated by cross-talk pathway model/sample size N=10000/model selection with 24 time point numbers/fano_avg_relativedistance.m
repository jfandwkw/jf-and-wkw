% ==== 预设参数 ====
T = 1;
numGroup = 24;                 % 共24个Excel文件
numCol = 100;                   % 每个文件前50列

% ==== 读取拟合参数 ====
data1 = xlsread('twostate_fitmethod_N10000_Smin.xlsx');

% ==== 初始化：每列的相对误差集合 ====
rel_error_matrix = NaN(numGroup, numCol);  % 行：组；列：列号

% ==== 主循环 ====
for j = 1:numGroup
    filename = sprintf('N10000_twostate_t%d.xlsx', j);
    datatemp = xlsread(filename);

    A2 = data1(j, 5);
    B2 = data1(j, 6);
    C2 = data1(j, 7);

    for k = 1:numCol
        TT = datatemp(10, k);
        fano_exp = datatemp(9, k);

        if isnan(TT) || isnan(fano_exp)
            continue;
        end

        t = 0:0.001:TT;
        M2_est = zeros(size(t));
        Var2 = zeros(size(t));
        Fano2 = zeros(size(t));

        for i = 1:length(t)
            if t(i) <= T
                M2_est(i) = -A2 * exp(-C2 * t(i)) + B2 * t(i) + A2;
                Var2(i) = B2^2 * t(i)^2 ...
                        + 2 * A2^2 * exp(-C2 * t(i)) * (-1 + exp(C2 * t(i)) - C2 * t(i)) ...
                        + (1 / C2) * 4 * A2 * B2 * (-1 + exp(-C2 * t(i)) + C2 * t(i)) ...
                        + M2_est(i) - M2_est(i)^2;
            else
                M2_est(i) = A2 * exp(-C2 * t(i)) * (-1 + exp(C2 * T)) + B2 * T;
                Var2(i) = 2 * (-A2^2 * C2 * T * exp(-C2 * t(i)) ...
                            - A2 * B2 * t(i) * exp(-C2 * t(i)) * (1 - exp(C2 * T)) ...
                            + A2 * B2 * (t(i) * exp(-C2 * t(i)) ...
                            - (t(i) - T) * exp(-C2 * (t(i) - T)) ...
                            + (1 / C2) * exp(-C2 * t(i)) * (1 - exp(C2 * T))) ...
                            - A2^2 * exp(-C2 * t(i)) * (1 - exp(C2 * T)) ...
                            - (1 / C2) * A2 * B2 * (1 - exp(-C2 * T)) ...
                            + 0.5 * B2^2 * T^2 + A2 * B2 * T) ...
                            + M2_est(i) - M2_est(i)^2;
            end
            Fano2(i) = Var2(i) / M2_est(i);
        end

        [~, idx_TT] = min(abs(t - TT));
        fano_calc = Fano2(idx_TT);
        rel_error = (fano_exp - fano_calc) / fano_calc;

        rel_error_matrix(j, k) = rel_error;
    end
end

% ==== 每列平均相对误差 ====
mean_rel_error_col = nanmean((rel_error_matrix), 1);  % 绝对值平均

% ==== 计算平均相对误差 >= 1 的占比 ====
num_large_error = sum(mean_rel_error_col >= 1);
ratio_large_error = num_large_error / numCol;

% ==== 输出 ====
fprintf('2状态拟合2路径 满足平均相对误差 >= 1 的列数为 %d，共 %d 列。\n', num_large_error, numCol);
fprintf('占比为：%.2f%%\n', ratio_large_error * 100);

% ==== 保存到 Excel ====
col_id = (1:numCol)';
output_table = table(col_id, mean_rel_error_col', 'VariableNames', {'Column', 'Mean_Rel_Error'});
writetable(output_table, 'Column_Mean_RelError.xlsx');