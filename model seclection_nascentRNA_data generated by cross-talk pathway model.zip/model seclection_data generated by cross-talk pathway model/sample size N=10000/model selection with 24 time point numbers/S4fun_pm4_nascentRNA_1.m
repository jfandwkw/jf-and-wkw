function S4 = S4fun_pm4_nascentRNA_1(bb4)
%%%% ��С����

global  t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24 m second fanodata %%����

T=[t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24];

b4=[exp(bb4(1)) exp(bb4(2)) 1+4999./(exp(bb4(3))+1)];
% b4(4)=1;
T1=1;

A=b4(3)*b4(2)/(b4(1)+b4(2))^2;
B=b4(3)*b4(1)/(b4(1)+b4(2));
C=b4(1)+b4(2);

for t = 1:1:length(T);
    if T(t)<= T1
        xmean(t)=-A*exp(-C*T(t))+B*T(t)+A;
        u2(t)=B^2*T(t)^2+2*(A^2)*exp(-C*T(t))*(-1+exp(C*T(t))-C*T(t))+(1/C)*4*A*B*(-1+exp(-C*T(t))+C*T(t))+xmean(t);
        xfano(t)=(u2(t)-(xmean(t)).^2)./xmean(t);
    else
        xmean(t)=A*exp(-C*T(t))*(-1+exp(T1*C))+B*T1;
        u2(t)=2*(-A^2*C*T1*exp(-C*T(t))-A*B*T(t).*exp(-C*T(t))*(1-exp(C*T1))+A*B*(T(t).*exp(-C*T(t))-(T(t)-T1).*exp(-C*(T(t)-T1))+(1/C)*exp(-C*T(t))*(1-exp(C*T1)))-A^2*exp(-C*T(t)).*(1-exp(C*T1))-(1/C)*A*B*(1-exp(-C*T1))+(1/2)*B^2*T1^2+A*B*T1)+xmean(t);
        xfano(t)=(u2(t)-(xmean(t)).^2)./xmean(t);
    end
    
end
%end
b4;
%% ��ֵ����

Smean = 0;
for i = 1:length(m)
    Smean = Smean+(xmean(i)-m(i)).^2./m(i).^2;
end

Su2 = 0;
for i = 1:length(second)
    Su2 = Su2+(u2(i)-second(i)).^2./second(i).^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano+(xfano(i)-fanodata(i)).^2./fanodata(i).^2;
end

S4=Smean+Su2+Sfano;
% S4=Smean;


end