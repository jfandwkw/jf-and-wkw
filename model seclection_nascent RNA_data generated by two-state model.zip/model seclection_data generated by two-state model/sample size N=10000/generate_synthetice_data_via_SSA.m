function endtest_2_state_nascentRNA

clc;
close all;
clear all;

data2=xlsread('parameter.xlsx');

for zushu = 1:1:100
    tic;  % ��ʱ��
    %% ��ʼ������
    clearvars -except zushu data2;

    a2=data2(:,zushu);
    real_para=data2(1:3,zushu); %2״̬����
    
%     lam_T = 0.1 + 2.9 * rand();
%     gamma_T = 0.1 + 2.9 * rand();
%     nu_T = 5 + 25 * rand();

    lam_T = real_para(1);
    gamma_T = real_para(2);
    nu_T = real_para(3);
    T1 = 1;

    k_01 = lam_T;
    k_10 = gamma_T;
    r = nu_T;
    lam = k_01;
    gamma = k_10;
    nu = r;

    str1 = {num2str(lam), num2str(gamma), num2str(nu)}';

    %% ʱ����ɢ��
    TT = 200;
    H = 200;
    eps = 0.01;
    TP(1) = TT / H;
    for i = 2:H
        TP(i) = TT / H + TP(i - 1);
    end

    %% ���۾�ֵ�ͷ������
    A = r * k_10 / (k_01 + k_10)^2;
    B = r * k_01 / (k_01 + k_10);
    C = k_01 + k_10;
    t = 0:0.001:200;
    Fano = zeros(size(t));
    for i = 1:length(t)
        if t(i) <= T1
            M1(i) = -A * exp(-C * t(i)) + B * t(i) + A; % ��ֵ
            Var(i) = B^2 * t(i)^2 + 2 * A^2 * exp(-C * t(i)) * (-1 + exp(C * t(i)) - C * t(i)) + ...
                     4 * A * B / C * (-1 + exp(-C * t(i)) + C * t(i)) + M1(i) - M1(i)^2; % ����
            M2(i) = Var(i) + M1(i)^2; % ���׾�
            Fano(i) = Var(i) / M1(i); % Fano ����
        else
            M1(i) = A * exp(-C * t(i)) * (-1 + exp(T1 * C)) + B * T1;
            Var(i) = 2 * (-A^2 * C * T1 * exp(-C * t(i)) - A * B * t(i) * exp(-C * t(i)) * (1 - exp(C * T1)) + ...
                         A * B * (t(i) * exp(-C * t(i)) - (t(i) - T1) * exp(-C * (t(i) - T1)) + ...
                         exp(-C * t(i)) / C * (1 - exp(C * T1))) - A^2 * exp(-C * t(i)) * (1 - exp(C * T1)) - ...
                         A * B / C * (1 - exp(-C * T1)) + B^2 * T1^2 / 2 + A * B * T1) + M1(i) - M1(i)^2;
            M2(i) = Var(i) + M1(i)^2;
            Fano(i) = Var(i) / M1(i);
        end
    end

    %% ȷ���ȶ���
    for j = 1:H
        for i = 1:length(t)
            if t(i) >= TP(j)
                break;
            end
            k(j) = i + 1;
        end
    end

    for j = 1:H
        meandata(j) = M1(k(j));
        seconddata(j) = M2(k(j));
    end

    k = H;
    for j = 1:H
        if abs(meandata(H) - meandata(H - j)) / meandata(H) <= eps
            k = k - 1;
        else
            break;
        end
    end
    meantime = k * (TT / H);

    k1 = H;
    for j = 1:H
        if abs(seconddata(H) - seconddata(H - j)) / seconddata(H) < eps
            k1 = k1 - 1;
        else
            break;
        end
    end
    secondtime = k1 * (TT / H);

    tend = max(meantime, secondtime);

    P = 24;
    t_values = round((1:P) * tend / P * 1000) / 1000;

    
    %% ���� Excel ���λ��
    if zushu <= 26
        location = char(65 + mod(zushu - 1, 100));
    elseif zushu <= 52
        location = char([65 + mod(0, 100), 65 + mod(zushu - 27, 100)]);
    elseif zushu <= 78
        location = char([65 + mod(1, 100), 65 + mod(zushu - 53, 100)]);
    else
        location = char([65 + mod(2, 100), 65 + mod(zushu - 79, 100)]);
    end

    range1 = [location, '1:', location, '3'];

    filenames = cell(1, P);
    for i = 1:P
        filenames{i} = ['N10000_twostate_t', num2str(i), '.xlsx'];
        xlswrite(filenames{i}, str1, 1, range1);
    end

    %% ģ�� nascent RNA ����
    N = 10000;
    num = 1000;

    nascent_storage = zeros(P, N);

    for t_idx = 1:P
        t_point = t_values(t_idx);
        for j = 1:N
            store = zeros(num + 1, 2);
            time = 0;
            initiation = 0;
            state = 1;
            for i = 2:num + 1
                react = (k_10 + r) * state - k_01 * (state - 1);
                rand_num = rand(2, 1);
                tau = -log(rand_num(1)) / react;
                if state == 1
                    if rand_num(2) < k_10 / react
                        state = 0;
                    else
                        initiation = initiation + 1;
                    end
                else
                    state = 1;
                end
                time = time + tau;
                store(i, :) = [initiation time];
%                 if time >= T1 && store(i-1, 2) < T1 % ������ԽT1��ʱ���
%                     if rand_num(2) >= k_10 / react
%                         initiation = initiation + 1;
%                     end
%                     state = 1;
%                 end
            end
            diff = abs(t_point - store(:, 2));
            [~, I] = min(diff);
            if store(I, 2) < t_point
                mRNA = store(I, 1);
            else
                mRNA = store(I - 1, 1);
            end
            if t_point > T1
                % ��ȥ (t_point - T1) ʱ������
                diff_T1 = abs((t_point - T1) - store(:, 2));
                [~, I_T1] = min(diff_T1);
                if store(I_T1, 2) < (t_point - T1)
                    mRNA_T1 = store(I_T1, 1);
                else
                    mRNA_T1 = store(I_T1 - 1, 1);
                end
                nascent_storage(t_idx, j) = mRNA - mRNA_T1;
            else
                nascent_storage(t_idx, j) = mRNA;
            end
        end
    end

    %% ����Ƶ�ʡ�һ�׾غͶ��׾�
    M = ceil(3 * nu + 1) + 200; % ���� M
    xdata = zeros(P, M);
    mean_values = zeros(P, 1);
    second_values = zeros(P, 1);

    for t_idx = 1:P
        xdata(t_idx, :) = histcounts(nascent_storage(t_idx, :), 0:M) / N;
        mean_values(t_idx) = sum((0:M - 1) .* xdata(t_idx, :));
        second_values(t_idx) = sum(((0:M - 1).^2) .* xdata(t_idx, :));
        fano_values(t_idx) = (second_values(t_idx) - mean_values(t_idx)^2) /mean_values(t_idx);
    end

    range2 = [location, '4:', location, '7'];
    range3 = [location, '8'];

    for i = 1:P
        str2 = {num2str(mean_values(i)), num2str(second_values(i)), num2str(fano_values(i)), num2str(t_values(i))}';
        xlswrite(filenames{i}, str2, 1, range2);
        xlswrite(filenames{i}, xdata(i, :)', 1, range3);
    end

    disp(['Completed iteration: ', num2str(zushu)]);
    toc
end
end
