function endtest_three_state

clc;
close all;
clear all;

data2=xlsread('parameter.xlsx');

for zushu = 1:1:100
    tic;  % ��ʱ��
    %% ��ʼ������
    clearvars -except zushu data2;

    a2=data2(:,zushu);
    real_para=data2(1:4,zushu); %2״̬����
    
    lam_1 = real_para(1);
    lam_2 = real_para(2);
    gamma = real_para(3);
    nu = real_para(4);
    delta = 1;
    
    str1 = {num2str(lam_1), num2str(lam_2), num2str(gamma), num2str(nu)}';
    %% ʱ����ɢ��
    TT = 200;
    H = 200;
    eps = 0.01;
    TP(1) = TT / H;
    for i = 2:H
        TP(i) = TT / H + TP(i - 1);
    end

    %%%%%%%%%%%%%%%%%%crosstalking
   
   odefun=@(t,y)[
gamma*y(3)-lam_1*y(1);
lam_1*y(1)-lam_2*y(2);
lam_2*y(2)-gamma*y(3);
nu*y(3)-delta*y(4);
-(lam_1+delta)*y(5)+gamma*y(7);
-(lam_2+delta)*y(6)+lam_1*y(5);
-(gamma+delta)*y(7)+lam_2*y(6)+nu*y(3);
-2*delta*y(8)+delta*y(4)+nu*y(3)+2*nu*y(7)
];

y00=[1,0,0,0,0,0,0,0];
options=odeset('reltol',1e-6,'abstol',1e-8);
[t,y]=ode45(odefun,[0,TT],y00,options);


    for j=1:1:H
        for i=1:1:length(t)
            if t(i)>=TP(j)
                break
            end
            k(j)=i+1;
        end
    end

    for j=1:1:H
        meandata(j)=y(k(j),4);
        seconddata(j)=y(k(j),8);
    end

    k=H;
    for j=1:1:H

        if  abs(meandata(H)-meandata(H-j))/meandata(H)<=eps
            k=k-1;
        else
            break
        end
    end
    meantime=k*(TT/H);

    k1=H;
    for j=1:1:H
        if  abs(seconddata(H)-seconddata(H-j))/seconddata(H)<eps
            k1=k1-1;
        else
            break
        end
    end
    secondtime=k1*(TT/H);

    tend=max(meantime,secondtime);

    P=24;
    t1=round(1*tend/P*1000)/1000;
    t2=round(2*tend/P*1000)/1000;
    t3=round(3*tend/P*1000)/1000;
    t4=round(4*tend/P*1000)/1000;
    t5=round(5*tend/P*1000)/1000;
    t6=round(6*tend/P*1000)/1000;
    t7=round(7*tend/P*1000)/1000;
    t8=round(8*tend/P*1000)/1000;
    t9=round(9*tend/P*1000)/1000;
    t10=round(10*tend/P*1000)/1000;
    t11=round(11*tend/P*1000)/1000;
    t12=round(12*tend/P*1000)/1000;
    t13=round(13*tend/P*1000)/1000;
    t14=round(14*tend/P*1000)/1000;
    t15=round(15*tend/P*1000)/1000;
    t16=round(16*tend/P*1000)/1000;
    t17=round(17*tend/P*1000)/1000;
    t18=round(18*tend/P*1000)/1000;
    t19=round(19*tend/P*1000)/1000;
    t20=round(20*tend/P*1000)/1000;
    t21=round(21*tend/P*1000)/1000;
    t22=round(22*tend/P*1000)/1000;
    t23=round(23*tend/P*1000)/1000;
    t24=round(24*tend/P*1000)/1000;

    %%

    if zushu<=26
        location=char(65+mod(zushu-1,100));
    elseif zushu<=52
        location=char([65+mod(0,100), 65+mod(zushu-27,100)]);
    elseif zushu<=78
        location=char([65+mod(1,100), 65+mod(zushu-53,100)]);
    else
        location=char([65+mod(2,100), 65+mod(zushu-79,100)]);
    end

    range1=[location,'1:',location,'4'];

    filename1='N10000_twostate_t1.xlsx';
    xlswrite(filename1,str1,1,range1)
    filename2='N10000_twostate_t2.xlsx';
    xlswrite(filename2,str1,1,range1)
    filename3='N10000_twostate_t3.xlsx';
    xlswrite(filename3,str1,1,range1)
    filename4='N10000_twostate_t4.xlsx';
    xlswrite(filename4,str1,1,range1)
    filename5='N10000_twostate_t5.xlsx';
    xlswrite(filename5,str1,1,range1)
    filename6='N10000_twostate_t6.xlsx';
    xlswrite(filename6,str1,1,range1)
    filename7='N10000_twostate_t7.xlsx';
    xlswrite(filename7,str1,1,range1)
    filename8='N10000_twostate_t8.xlsx';
    xlswrite(filename8,str1,1,range1)
    filename9='N10000_twostate_t9.xlsx';
    xlswrite(filename9,str1,1,range1)
    filename10='N10000_twostate_t10.xlsx';
    xlswrite(filename10,str1,1,range1)
    filename11='N10000_twostate_t11.xlsx';
    xlswrite(filename11,str1,1,range1)
    filename12='N10000_twostate_t12.xlsx';
    xlswrite(filename12,str1,1,range1)
    filename13='N10000_twostate_t13.xlsx';
    xlswrite(filename13,str1,1,range1)
    filename14='N10000_twostate_t14.xlsx';
    xlswrite(filename14,str1,1,range1)
    filename15='N10000_twostate_t15.xlsx';
    xlswrite(filename15,str1,1,range1)
    filename16='N10000_twostate_t16.xlsx';
    xlswrite(filename16,str1,1,range1)
    filename17='N10000_twostate_t17.xlsx';
    xlswrite(filename17,str1,1,range1)
    filename18='N10000_twostate_t18.xlsx';
    xlswrite(filename18,str1,1,range1)
    filename19='N10000_twostate_t19.xlsx';
    xlswrite(filename19,str1,1,range1)
    filename20='N10000_twostate_t20.xlsx';
    xlswrite(filename20,str1,1,range1)
    filename21='N10000_twostate_t21.xlsx';
    xlswrite(filename21,str1,1,range1)
    filename22='N10000_twostate_t22.xlsx';
    xlswrite(filename22,str1,1,range1)
    filename23='N10000_twostate_t23.xlsx';
    xlswrite(filename23,str1,1,range1)
    filename24='N10000_twostate_t24.xlsx';
    xlswrite(filename24,str1,1,range1)

    %%-------------------------------------
    delta = 1;
    N = 10000;  %%ϸ������
    T = tend;    %%���ʱ��
    M=ceil(3*nu+1)+200;    %%���mRNA����
    X(1) = 0; t(1) = 0;  % ��ʼmRNA��������ʼʱ��



    S1 = []; S2 = []; S3=[]; S4=[]; S5=[]; S6=[]; S7=[]; S8=[]; S9=[]; S10=[];
    S11 = []; S12 = []; S13=[]; S14=[]; S15=[]; S16=[]; S17=[]; S18=[]; S19=[]; S20=[];
    S21 = []; S22 = []; S23=[]; S24=[];

    for i = 1:N
        s(1)=1; %��ʼ״̬off1
        n = 1;
        Xall = [X(1)]; Sall = [s(1)]; tall = [t(1)];

        %         %%%% external noise; nu1 is random variable , ���Ӷ�����̬�ֲ� log(nu1)��N(mu,sigma)
        %         nu; % nu1�ľ�ֵ
        %         sta=0.05; % nu1�ı�׼��
        %         mu = log((nu^2)/sqrt(sta+nu^2)); %���������̬�ֲ����ӵĲ���
        %         sigma = sqrt(log(sta/(nu^2)+1)); %���������̬�ֲ����ӵĲ���
        %         nu1=lognrnd(mu,sigma); %������̬�ֲ��������������

        % nu; % nu1�ľ�ֵ
        % sta=0.05*nu; % nu1�ı�׼��
        % mu = log((nu^2)/sqrt(sta+nu^2)); %���������̬�ֲ����ӵĲ���
        % sigma = sqrt(log(sta/(nu^2)+1)); %���������̬�ֲ����ӵĲ���
        % nu1=lognrnd(mu,sigma); %������̬�ֲ��������������

        while t(n) <= T
            h1 = 1; c1 = nu; a1 = h1*c1; % generate
            h2 = 1; c2 = gamma; a2 = h2*c2; % ON -->off1
            h3 = 1; c3 = lam_1; a3 = h3*c3;  % off1 --> off2
            h4 = 1; c4 = lam_2; a4 = h4*c4;  % off2 --> ON
            h5 = X(n); c5 = delta; a5 = h5*c5;  % decay
            n = n+1;

            if s(n-1) == 0 % ON
                a0 = a1+a2+a5;
                r1 = rand; r2=rand;
                tau = -log(r1)/a0;  % time interval in which nothing occurs

                if a0*r2 <= a1 % generate occurs
                    X(n)=X(n-1)+1;  s(n)=0;
                elseif a0*r2 <=a1+a2  % transition occurs on--off1
                    X(n)=X(n-1);s(n)=1;
                else % decay
                    X(n)=X(n-1)-1; s(n)=0;
                end
                t(n) = t(n-1) + tau;
            elseif s(n-1) == 1 % off1
                a0 = a3+a5;
                r1=rand;  r2=rand;
                tau=-log(r1)/a0;
                if a0*r2 <= a3 % transition occurs off1--off2
                    X(n)=X(n-1); s(n)=2;
                else % decy occurs
                    X(n)=X(n-1)-1; s(n)=1;
                end
                t(n) = t(n-1) + tau;
            else  % off2
                a0 = a4+a5;
                r1=rand;  r2=rand;
                tau=-log(r1)/a0;
                if a0*r2 <= a4  % transition occurs off2--on
                    X(n)=X(n-1); s(n)=0;
                else  % decay occurs
                    X(n)=X(n-1)-1; s(n)=2;
                end
                t(n) = t(n-1) + tau;
            end
            Xall = [Xall X(n)]; Sall = [Sall s(n)]; tall = [tall t(n)];
        end


        if t(n)<T;
            Xall=[Xall X(n)]; Sall=[Sall s(n)]; tall=[tall T];
        end

        
        for j=2:n
            if t(j-1) <=t1 && t(j) >t1;
                S1 = [S1 X(j-1)];
            end
            if t(j-1) <=t2 && t(j) >t2;
                S2 = [S2 X(j-1)];
            end
            if t(j-1) <=t3 && t(j) >t3;
                S3 = [S3 X(j-1)];
            end
            if t(j-1) <=t4 && t(j) >t4;
                S4 = [S4 X(j-1)];
            end
            if t(j-1) <=t5 && t(j) >t5;
                S5 = [S5 X(j-1)];
            end
            if t(j-1) <=t6 && t(j) >t6;
                S6 = [S6 X(j-1)];
            end
            if t(j-1) <=t7 && t(j) >t7;
                S7 = [S7 X(j-1)];
            end
            if t(j-1) <=t8 && t(j) >t8;
                S8 = [S8 X(j-1)];
            end
            if t(j-1) <=t9 && t(j) >t9;
                S9 = [S9 X(j-1)];
            end
            if t(j-1) <=t10 && t(j) >t10;
                S10 = [S10 X(j-1)];
            end
            if t(j-1) <=t11 && t(j) >t11;
                S11 = [S11 X(j-1)];
            end
            if t(j-1) <=t12 && t(j) >t12;
                S12 = [S12 X(j-1)];
            end
            if t(j-1) <=t13 && t(j) >t13;
                S13 = [S13 X(j-1)];
            end
            if t(j-1) <=t14 && t(j) >t14;
                S14 = [S14 X(j-1)];
            end
            if t(j-1) <=t15 && t(j) >t15;
                S15 = [S15 X(j-1)];
            end
            if t(j-1) <=t16 && t(j) >t16;
                S16 = [S16 X(j-1)];
            end
            if t(j-1) <=t17 && t(j) >t17;
                S17 = [S17 X(j-1)];
            end
            if t(j-1) <=t18 && t(j) >t18;
                S18 = [S18 X(j-1)];
            end
            if t(j-1) <=t19 && t(j) >t19;
                S19 = [S19 X(j-1)];
            end
            if t(j-1) <=t20 && t(j) >t20;
                S20 = [S20 X(j-1)];
            end
            if t(j-1) <=t21 && t(j) >t21;
                S21 = [S21 X(j-1)];
            end
            if t(j-1) <=t22 && t(j) >t22;
                S22 = [S22 X(j-1)];
            end
            if t(j-1) <=t23 && t(j) >t23;
                S23 = [S23 X(j-1)];
            end
            if t(j-1) <=t24 && t(j) >t24;
                S24 = [S24 X(j-1)];
            end
        end

    end

    for i = 1:M
        xdata1(i) = sum(S1==(i-1))/N;
    end
    for i = 1:M
        xdata2(i) = sum(S2==(i-1))/N;
    end
    for i = 1:M
        xdata3(i) = sum(S3==(i-1))/N;
    end
    for i = 1:M
        xdata4(i) = sum(S4==(i-1))/N;
    end
    for i = 1:M
        xdata5(i) = sum(S5==(i-1))/N;
    end
    for i = 1:M
        xdata6(i) = sum(S6==(i-1))/N;
    end
    for i = 1:M
        xdata7(i) = sum(S7==(i-1))/N;
    end
    for i = 1:M
        xdata8(i) = sum(S8==(i-1))/N;
    end
    for i = 1:M
        xdata9(i) = sum(S9==(i-1))/N;
    end
    for i = 1:M
        xdata10(i) = sum(S10==(i-1))/N;
    end
    for i = 1:M
        xdata11(i) = sum(S11==(i-1))/N;
    end
    for i = 1:M
        xdata12(i) = sum(S12==(i-1))/N;
    end
    for i = 1:M
        xdata13(i) = sum(S13==(i-1))/N;
    end
    for i = 1:M
        xdata14(i) = sum(S14==(i-1))/N;
    end
    for i = 1:M
        xdata15(i) = sum(S15==(i-1))/N;
    end
    for i = 1:M
        xdata16(i) = sum(S16==(i-1))/N;
    end
    for i = 1:M
        xdata17(i) = sum(S17==(i-1))/N;
    end
    for i = 1:M
        xdata18(i) = sum(S18==(i-1))/N;
    end
    for i = 1:M
        xdata19(i) = sum(S19==(i-1))/N;
    end
    for i = 1:M
        xdata20(i) = sum(S20==(i-1))/N;
    end
    for i = 1:M
        xdata21(i) = sum(S21==(i-1))/N;
    end
    for i = 1:M
        xdata22(i) = sum(S22==(i-1))/N;
    end
    for i = 1:M
        xdata23(i) = sum(S23==(i-1))/N;
    end
    for i = 1:M
        xdata24(i) = sum(S24==(i-1))/N;
    end

    S=numel(xdata1);

    mean1=0;
    for i=1:1:S
        mean1=mean1+(i-1).*xdata1(i);
    end
    Second1=0;
    for i=1:1:S
        Second1=Second1+((i-1)^2).*xdata1(i);
    end
    fano1=Second1/mean1-mean1;

    mean2=0;
    for i=1:1:S
        mean2=mean2+(i-1).*xdata2(i);
    end
    Second2=0;
    for i=1:1:S
        Second2=Second2+((i-1)^2).*xdata2(i);
    end
    fano2=Second2/mean2-mean2;

    mean3=0;
    for i=1:1:S
        mean3=mean3+(i-1).*xdata3(i);
    end
    Second3=0;
    for i=1:1:S
        Second3=Second3+((i-1)^2).*xdata3(i);
    end
    fano3=Second3/mean3-mean3;

    mean4=0;
    for i=1:1:S
        mean4=mean4+(i-1).*xdata4(i);
    end
    Second4=0;
    for i=1:1:S
        Second4=Second4+((i-1)^2).*xdata4(i);
    end
    fano4=Second4/mean4-mean4;

    mean5=0;
    for i=1:1:S
        mean5=mean5+(i-1).*xdata5(i);
    end
    Second5=0;
    for i=1:1:S
        Second5=Second5+((i-1)^2).*xdata5(i);
    end
    fano5=Second5/mean5-mean5;

    mean6=0;
    for i=1:1:S
        mean6=mean6+(i-1).*xdata6(i);
    end
    Second6=0;
    for i=1:1:S
        Second6=Second6+((i-1)^2).*xdata6(i);
    end
    fano6=Second6/mean6-mean6;

    mean7=0;
    for i=1:1:S
        mean7=mean7+(i-1).*xdata7(i);
    end
    Second7=0;
    for i=1:1:S
        Second7=Second7+((i-1)^2).*xdata7(i);
    end
    fano7=Second7/mean7-mean7;

    mean8=0;
    for i=1:1:S
        mean8=mean8+(i-1).*xdata8(i);
    end
    Second8=0;
    for i=1:1:S
        Second8=Second8+((i-1)^2).*xdata8(i);
    end
    fano8=Second8/mean8-mean8;

    mean9=0;
    for i=1:1:S
        mean9=mean9+(i-1).*xdata9(i);
    end
    Second9=0;
    for i=1:1:S
        Second9=Second9+((i-1)^2).*xdata9(i);
    end
    fano9=Second9/mean9-mean9;

    mean10=0;
    for i=1:1:S
        mean10=mean10+(i-1).*xdata10(i);
    end
    Second10=0;
    for i=1:1:S
        Second10=Second10+((i-1)^2).*xdata10(i);
    end
    fano10=Second10/mean10-mean10;

    mean11=0;
    for i=1:1:S
        mean11=mean11+(i-1).*xdata11(i);
    end
    Second11=0;
    for i=1:1:S
        Second11=Second11+((i-1)^2).*xdata11(i);
    end
    fano11=Second11/mean11-mean11;

    mean12=0;
    for i=1:1:S
        mean12=mean12+(i-1).*xdata12(i);
    end
    Second12=0;
    for i=1:1:S
        Second12=Second12+((i-1)^2).*xdata12(i);
    end
    fano12=Second12/mean12-mean12;

    mean13=0;
    for i=1:1:S
        mean13=mean13+(i-1).*xdata13(i);
    end
    Second13=0;
    for i=1:1:S
        Second13=Second13+((i-1)^2).*xdata13(i);
    end
    fano13=Second13/mean13-mean13;

    mean14=0;
    for i=1:1:S
        mean14=mean14+(i-1).*xdata14(i);
    end
    Second14=0;
    for i=1:1:S
        Second14=Second14+((i-1)^2).*xdata14(i);
    end
    fano14=Second14/mean14-mean14;

    mean15=0;
    for i=1:1:S
        mean15=mean15+(i-1).*xdata15(i);
    end
    Second15=0;
    for i=1:1:S
        Second15=Second15+((i-1)^2).*xdata15(i);
    end
    fano15=Second15/mean15-mean15;

    mean16=0;
    for i=1:1:S
        mean16=mean16+(i-1).*xdata16(i);
    end
    Second16=0;
    for i=1:1:S
        Second16=Second16+((i-1)^2).*xdata16(i);
    end
    fano16=Second16/mean16-mean16;

    mean17=0;
    for i=1:1:S
        mean17=mean17+(i-1).*xdata17(i);
    end
    Second17=0;
    for i=1:1:S
        Second17=Second17+((i-1)^2).*xdata17(i);
    end
    fano17=Second17/mean17-mean17;

    mean18=0;
    for i=1:1:S
        mean18=mean18+(i-1).*xdata18(i);
    end
    Second18=0;
    for i=1:1:S
        Second18=Second18+((i-1)^2).*xdata18(i);
    end
    fano18=Second18/mean18-mean18;

    mean19=0;
    for i=1:1:S
        mean19=mean19+(i-1).*xdata19(i);
    end
    Second19=0;
    for i=1:1:S
        Second19=Second19+((i-1)^2).*xdata19(i);
    end
    fano19=Second19/mean19-mean19;

    mean20=0;
    for i=1:1:S
        mean20=mean20+(i-1).*xdata20(i);
    end
    Second20=0;
    for i=1:1:S
        Second20=Second20+((i-1)^2).*xdata20(i);
    end
    fano20=Second20/mean20-mean20;

    mean21=0;
    for i=1:1:S
        mean21=mean21+(i-1).*xdata21(i);
    end
    Second21=0;
    for i=1:1:S
        Second21=Second21+((i-1)^2).*xdata21(i);
    end
    fano21=Second21/mean21-mean21;

    mean22=0;
    for i=1:1:S
        mean22=mean22+(i-1).*xdata22(i);
    end
    Second22=0;
    for i=1:1:S
        Second22=Second22+((i-1)^2).*xdata22(i);
    end
    fano22=Second22/mean22-mean22;

    mean23=0;
    for i=1:1:S
        mean23=mean23+(i-1).*xdata23(i);
    end
    Second23=0;
    for i=1:1:S
        Second23=Second23+((i-1)^2).*xdata23(i);
    end
    fano23=Second23/mean23-mean23;

    mean24=0;
    for i=1:1:S
        mean24=mean24+(i-1).*xdata24(i);
    end
    Second24=0;
    for i=1:1:S
        Second24=Second24+((i-1)^2).*xdata24(i);
    end
    fano24=Second24/mean24-mean24;


    %%-------------------------------------
    range2=[location,'5:',location,'8'];
    range3=[location,'9'];

    str2t1={num2str(mean1),num2str(Second1),num2str(fano1),num2str(t1)}';
    str2t2={num2str(mean2),num2str(Second2),num2str(fano2),num2str(t2)}';
    str2t3={num2str(mean3),num2str(Second3),num2str(fano3),num2str(t3)}';
    str2t4={num2str(mean4),num2str(Second4),num2str(fano4),num2str(t4)}';
    str2t5={num2str(mean5),num2str(Second5),num2str(fano5),num2str(t5)}';
    str2t6={num2str(mean6),num2str(Second6),num2str(fano6),num2str(t6)}';
    str2t7={num2str(mean7),num2str(Second7),num2str(fano7),num2str(t7)}';
    str2t8={num2str(mean8),num2str(Second8),num2str(fano8),num2str(t8)}';
    str2t9={num2str(mean9),num2str(Second9),num2str(fano9),num2str(t9)}';
    str2t10={num2str(mean10),num2str(Second10),num2str(fano10),num2str(t10)}';
    str2t11={num2str(mean11),num2str(Second11),num2str(fano11),num2str(t11)}';
    str2t12={num2str(mean12),num2str(Second12),num2str(fano12),num2str(t12)}';
    str2t13={num2str(mean13),num2str(Second13),num2str(fano13),num2str(t13)}';
    str2t14={num2str(mean14),num2str(Second14),num2str(fano14),num2str(t14)}';
    str2t15={num2str(mean15),num2str(Second15),num2str(fano15),num2str(t15)}';
    str2t16={num2str(mean16),num2str(Second16),num2str(fano16),num2str(t16)}';
    str2t17={num2str(mean17),num2str(Second17),num2str(fano17),num2str(t17)}';
    str2t18={num2str(mean18),num2str(Second18),num2str(fano18),num2str(t18)}';
    str2t19={num2str(mean19),num2str(Second19),num2str(fano19),num2str(t19)}';
    str2t20={num2str(mean20),num2str(Second20),num2str(fano20),num2str(t20)}';
    str2t21={num2str(mean21),num2str(Second21),num2str(fano21),num2str(t21)}';
    str2t22={num2str(mean22),num2str(Second22),num2str(fano22),num2str(t22)}';
    str2t23={num2str(mean23),num2str(Second23),num2str(fano23),num2str(t23)}';
    str2t24={num2str(mean24),num2str(Second24),num2str(fano24),num2str(t24)}';

    xlswrite(filename1,str2t1,1,range2);
    xlswrite(filename2,str2t2,1,range2);
    xlswrite(filename3,str2t3,1,range2);
    xlswrite(filename4,str2t4,1,range2);
    xlswrite(filename5,str2t5,1,range2);
    xlswrite(filename6,str2t6,1,range2);
    xlswrite(filename7,str2t7,1,range2);
    xlswrite(filename8,str2t8,1,range2);
    xlswrite(filename9,str2t9,1,range2);
    xlswrite(filename10,str2t10,1,range2);
    xlswrite(filename11,str2t11,1,range2);
    xlswrite(filename12,str2t12,1,range2);
    xlswrite(filename13,str2t13,1,range2);
    xlswrite(filename14,str2t14,1,range2);
    xlswrite(filename15,str2t15,1,range2);
    xlswrite(filename16,str2t16,1,range2);
    xlswrite(filename17,str2t17,1,range2);
    xlswrite(filename18,str2t18,1,range2);
    xlswrite(filename19,str2t19,1,range2);
    xlswrite(filename20,str2t20,1,range2);
    xlswrite(filename21,str2t21,1,range2);
    xlswrite(filename22,str2t22,1,range2);
    xlswrite(filename23,str2t23,1,range2);
    xlswrite(filename24,str2t24,1,range2);

    xlswrite(filename1,xdata1',1,range3);
    xlswrite(filename2,xdata2',1,range3);
    xlswrite(filename3,xdata3',1,range3);
    xlswrite(filename4,xdata4',1,range3);
    xlswrite(filename5,xdata5',1,range3);
    xlswrite(filename6,xdata6',1,range3);
    xlswrite(filename7,xdata7',1,range3);
    xlswrite(filename8,xdata8',1,range3);
    xlswrite(filename9,xdata9',1,range3);
    xlswrite(filename10,xdata10',1,range3);
    xlswrite(filename11,xdata11',1,range3);
    xlswrite(filename12,xdata12',1,range3);
    xlswrite(filename13,xdata13',1,range3);
    xlswrite(filename14,xdata14',1,range3);
    xlswrite(filename15,xdata15',1,range3);
    xlswrite(filename16,xdata16',1,range3);
    xlswrite(filename17,xdata17',1,range3);
    xlswrite(filename18,xdata18',1,range3);
    xlswrite(filename19,xdata19',1,range3);
    xlswrite(filename20,xdata20',1,range3);
    xlswrite(filename21,xdata21',1,range3);
    xlswrite(filename22,xdata22',1,range3);
    xlswrite(filename23,xdata23',1,range3);
    xlswrite(filename24,xdata24',1,range3);


    zushu
    toc
end
%%-------------------------------------
% plot(tdata,xdata,'b.')
% hold on

