function S4 = S4fun_pm4_nascentRNA_1(bb4)
%%%% ��С����

global  t2  t4  t6  t8  t10  t12  t14  t16  t18  t20  t22  t24 m second fanodata %%����

T=[t2  t4  t6  t8  t10  t12  t14  t16  t18  t20  t22  t24];

b4=[exp(bb4(1)) exp(bb4(2)) 1+4999./(exp(bb4(3))+1)];
b4(4)=1; %delta=1


for t = 1:1:length(T);

    xmean(t)=b4(1).*b4(3)./((b4(1)+b4(2)).*b4(4))-b4(1).*b4(3)./((b4(1)+b4(2)).*(b4(4)-b4(1)-b4(2))).*exp(-(b4(1)+b4(2)).*T(t))+b4(1).*b4(3)./(b4(4).*(b4(4)-b4(1)-b4(2))).*exp(-b4(4).*T(t));

    u2(t)=(b4(3).*b4(4).*(b4(4)+b4(1)+b4(2))+b4(3).^2.*(b4(4)+b4(1))).*b4(1)./(b4(4).^2.*(b4(1)+b4(2)).*(b4(4)+b4(1)+b4(2)))...
        -(b4(3).*(2*b4(4).^2-b4(1).*b4(4)-b4(2).*b4(4)+2.*b4(3).*b4(4)-2*b4(3).*b4(2))).*b4(1)./(b4(4).*(b4(1)+b4(2)).*(b4(4)-(b4(1)+b4(2))).*(2*b4(4)-(b4(1)+b4(2)))).*exp(-(b4(1)+b4(2)).*T(t))...
        -(b4(1).*b4(3).*b4(4).*(b4(1)+b4(2))+2*b4(1).^2*b4(3).^2)./(b4(4).^2.*(b4(1)+b4(2)).*(b4(1)+b4(2)-b4(4))).*exp(-b4(4).*T(t))...
        +b4(1).*b4(3).^2.*(b4(1)-b4(4))./(b4(4).^2.*(b4(1)+b4(2)-2*b4(4)).*(b4(1)+b4(2)-b4(4))).*exp(-2*b4(4).*T(t))...
        +2.*b4(3).^2.*b4(1).*b4(2)./(b4(4).*(b4(1)+b4(2)).*(b4(4)+b4(1)+b4(2)).*(b4(4)-b4(1)-b4(2))).*exp(-(b4(4)+b4(1)+b4(2)).*T(t));

    xfano(t)=(u2(t)-(xmean(t)).^2)./xmean(t);


end
b4;
%% ��ֵ����

Smean = 0;
for i = 1:length(m)
    Smean = Smean+(xmean(i)-m(i)).^2./m(i).^2;
end

Su2 = 0;
for i = 1:length(second)
    Su2 = Su2+(u2(i)-second(i)).^2./second(i).^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano+(xfano(i)-fanodata(i)).^2./fanodata(i).^2;
end

S4=Smean+Su2+Sfano;
% S4=Smean;


end