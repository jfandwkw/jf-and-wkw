function parfit_twostate_nascentRNA_1
%clear
clc
close all
clear all

str={'la1r','la2r','gar','vr',...
'�س�ֵ1','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ2','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ3','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ4','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ5','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ6','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ7','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ8','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ9','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ10','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ11','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ12','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ13','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ14','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ15','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ16','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ17','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ18','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ19','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ20','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ21','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ22','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ23','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ24','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ25','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ26','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ27','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ28','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ29','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ30','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ31','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ32','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ33','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ34','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ35','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ36','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ37','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ38','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ39','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ40','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ41','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ42','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ43','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ44','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ45','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ46','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ47','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ48','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ49','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time',...
'�س�ֵ50','la1', 'la2', ' ga',' v',' ������','ree_la1', 'ree_la2',' ree_ga',' ree_v',' LS value',' time'};





filename='twostate_fitmethod_N10000.xlsx';

data1=xlsread('N10000_twostate_t1.xlsx');
data2=xlsread('N10000_twostate_t2.xlsx');
data3=xlsread('N10000_twostate_t3.xlsx');
data4=xlsread('N10000_twostate_t4.xlsx');
data5=xlsread('N10000_twostate_t5.xlsx');
data6=xlsread('N10000_twostate_t6.xlsx');
data7=xlsread('N10000_twostate_t7.xlsx');
data8=xlsread('N10000_twostate_t8.xlsx');
data9=xlsread('N10000_twostate_t9.xlsx');
data10=xlsread('N10000_twostate_t10.xlsx');
data11=xlsread('N10000_twostate_t11.xlsx');
data12=xlsread('N10000_twostate_t12.xlsx');
data13=xlsread('N10000_twostate_t13.xlsx');
data14=xlsread('N10000_twostate_t14.xlsx');
data15=xlsread('N10000_twostate_t15.xlsx');
data16=xlsread('N10000_twostate_t16.xlsx');
data17=xlsread('N10000_twostate_t17.xlsx');
data18=xlsread('N10000_twostate_t18.xlsx');
data19=xlsread('N10000_twostate_t19.xlsx');
data20=xlsread('N10000_twostate_t20.xlsx');
data21=xlsread('N10000_twostate_t21.xlsx');
data22=xlsread('N10000_twostate_t22.xlsx');
data23=xlsread('N10000_twostate_t23.xlsx');
data24=xlsread('N10000_twostate_t24.xlsx');


xlswrite(filename,str,1,'A1')
strSmin={'la1r','la2r','gar','vr','��','la1','la2', 'ga',' v',' ������','ree_la1', 'ree_la2', ' ree_ga',' ree_v',' LS value',' time'};

filenameSmin='twostate_fitmethod_N10000_Smin.xlsx';
xlswrite(filenameSmin,strSmin,1,'A1')

%%-------------------------------------
 for zushu=1:1:100
%%-------------------------------------
  clearvars -except zushu data1 data2 data3 data4 data5 data6 data7 data8...
 data9 data10 data11 data12 data13 data14 data15 data16 data17 data18 data19...
 data20 data21 data22 data23 data24 filename filenameSmin

  
%%--------------------------------------

global  xdata1 xdata2 xdata3 xdata4 xdata5 xdata6 xdata7 xdata8 xdata9 xdata10 xdata11 xdata12 xdata13 xdata14 xdata15 xdata16 xdata17 xdata18 xdata19 xdata20 xdata21 xdata22 xdata23 xdata24...
        tt1 tt2 tt3 tt4 tt5 tt6 tt7 tt8 tt9 tt10 tt11 tt12 tt13 tt14 tt15 tt16 tt17 tt18 tt19 tt20 tt21 tt22 tt23 tt24...
         t1 t2 t3 t4 t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22 t23 t24 m second fanodata %%����

N=10000;

%%--------------------------------------
%&t1
a1=data1(:,zushu);
b1=length(a1);
xdata1=data1(10:b1,zushu);
real_para1=data1(1:9,zushu); %��״̬����
xdata1=clearnan(xdata1);%%ȥ��nanֵ

%&t2
a2=data2(:,zushu);
b2=length(a2);
xdata2=data2(10:b2,zushu);
real_para2=data2(1:9,zushu); %��״̬����
xdata2=clearnan(xdata2);%%ȥ��nanֵ

%&t3
a3=data3(:,zushu);
b3=length(a3);
xdata3=data3(10:b3,zushu);
real_para3=data3(1:9,zushu); %��״̬����
xdata3=clearnan(xdata3);%%ȥ��nanֵ

%&t4
a4=data4(:,zushu);
b4=length(a4);
xdata4=data4(10:b4,zushu);
real_para4=data4(1:9,zushu); %��״̬����
xdata4=clearnan(xdata4);%%ȥ��nanֵ

%&t5
a5=data5(:,zushu);
b5=length(a5);
xdata5=data5(10:b5,zushu);
real_para5=data5(1:9,zushu); %��״̬����
xdata5=clearnan(xdata5);%%ȥ��nanֵ

%&t6
a6=data6(:,zushu);
b6=length(a6);
xdata6=data6(10:b6,zushu);
real_para6=data6(1:9,zushu); %��״̬����
xdata6=clearnan(xdata6);%%ȥ��nanֵ


%&t7
a7=data7(:,zushu);
b7=length(a7);
xdata7=data7(10:b7,zushu);
real_para7=data7(1:9,zushu); %��״̬����
xdata7=clearnan(xdata7);%%ȥ��nanֵ


%&t8
a8=data8(:,zushu);
b8=length(a8);
xdata8=data8(10:b8,zushu);
real_para8=data8(1:9,zushu); %��״̬����
xdata8=clearnan(xdata8);%%ȥ��nanֵ

%&t9
a9=data9(:,zushu);
b9=length(a9);
xdata9=data9(10:b9,zushu);
real_para9=data9(1:9,zushu); %��״̬����
xdata9=clearnan(xdata9);%%ȥ��nanֵ

%&t10
a10=data10(:,zushu);
b10=length(a10);
xdata10=data10(10:b10,zushu);
real_para10=data10(1:9,zushu); %��״̬����
xdata10=clearnan(xdata10);%%ȥ��nanֵ

%&t11
a11=data11(:,zushu);
b11=length(a11);
xdata11=data11(10:b11,zushu);
real_para11=data11(1:9,zushu); %��״̬����
xdata11=clearnan(xdata11);%%ȥ��nanֵ

%&t12
a12=data12(:,zushu);
b12=length(a12);
xdata12=data12(10:b12,zushu);
real_para12=data12(1:9,zushu); %��״̬����
xdata12=clearnan(xdata12);%%ȥ��nanֵ

%&t13
a13=data13(:,zushu);
b13=length(a13);
xdata13=data13(10:b13,zushu);
real_para13=data13(1:9,zushu); %��״̬����
xdata13=clearnan(xdata13);%%ȥ��nanֵ

%&t14
a14=data14(:,zushu);
b14=length(a14);
xdata14=data14(10:b14,zushu);
real_para14=data14(1:9,zushu); %��״̬����
xdata14=clearnan(xdata14);%%ȥ��nanֵ

%&t15
a15=data15(:,zushu);
b15=length(a15);
xdata15=data15(10:b15,zushu);
real_para15=data15(1:9,zushu); %��״̬����
xdata15=clearnan(xdata15);%%ȥ��nanֵ

%&t16
a16=data16(:,zushu);
b16=length(a16);
xdata16=data16(10:b16,zushu);
real_para16=data16(1:9,zushu); %��״̬����
xdata16=clearnan(xdata16);%%ȥ��nanֵ


%&t17
a17=data17(:,zushu);
b17=length(a17);
xdata17=data17(10:b17,zushu);
real_para17=data17(1:9,zushu); %��״̬����
xdata17=clearnan(xdata17);%%ȥ��nanֵ


%&t18
a18=data18(:,zushu);
b18=length(a18);
xdata18=data18(10:b18,zushu);
real_para18=data18(1:9,zushu); %��״̬����
xdata18=clearnan(xdata18);%%ȥ��nanֵ

%&t19
a19=data19(:,zushu);
b19=length(a19);
xdata19=data19(10:b19,zushu);
real_para19=data19(1:9,zushu); %��״̬����
xdata19=clearnan(xdata19);%%ȥ��nanֵ

%&t20
a20=data20(:,zushu);
b20=length(a20);
xdata20=data20(10:b20,zushu);
real_para20=data20(1:9,zushu); %��״̬����
xdata20=clearnan(xdata20);%%ȥ��nanֵ

%&t21
a21=data21(:,zushu);
b21=length(a21);
xdata21=data21(10:b21,zushu);
real_para21=data21(1:9,zushu); %��״̬����
xdata21=clearnan(xdata21);%%ȥ��nanֵ

%&t22
a22=data22(:,zushu);
b22=length(a22);
xdata22=data22(10:b22,zushu);
real_para22=data22(1:9,zushu); %��״̬����
xdata22=clearnan(xdata22);%%ȥ��nanֵ

%&t23
a23=data23(:,zushu);
b23=length(a23);
xdata23=data23(10:b23,zushu);
real_para23=data23(1:9,zushu); %��״̬����
xdata23=clearnan(xdata23);%%ȥ��nanֵ


%&t24
a24=data24(:,zushu);
b24=length(a24);
xdata24=data24(10:b24,zushu);
real_para24=data24(1:9,zushu); %��״̬����
xdata24=clearnan(xdata24);%%ȥ��nanֵ


%%--------------------------------------

%%3״̬��ʵֵ
m=[real_para1(5) real_para2(5) real_para3(5) real_para4(5) real_para5(5) real_para6(5) real_para7(5) real_para8(5) real_para9(5) real_para10(5) real_para11(5) real_para12(5) real_para13(5) real_para14(5) real_para15(5) real_para16(5) real_para17(5) real_para18(5) real_para19(5) real_para20(5) real_para21(5) real_para22(5) real_para23(5) real_para24(5)];
second=[real_para1(6) real_para2(6) real_para3(6) real_para4(6) real_para5(6) real_para6(6) real_para7(6) real_para8(6) real_para9(6) real_para10(6) real_para11(6) real_para12(6) real_para13(6) real_para14(6) real_para15(6) real_para16(6) real_para17(6) real_para18(6) real_para19(6) real_para20(6) real_para21(6) real_para22(6) real_para23(6) real_para24(6)];
fanodata=[real_para1(7) real_para2(7) real_para3(7) real_para4(7) real_para5(7) real_para6(7) real_para7(7) real_para8(7) real_para9(7) real_para10(7) real_para11(7) real_para12(7) real_para13(7) real_para14(7) real_para15(7) real_para16(7) real_para17(7) real_para18(7) real_para19(7) real_para20(7) real_para21(7) real_para22(7) real_para23(7) real_para24(7)];
% lar=real_para24(1);
% gar=real_para24(2);
% vr1=real_para24(3);
% vr2=real_para24(4);
% vr=vr1.*vr2./(vr1+vr2);

la1r=real_para24(1);
la2r=real_para24(2);

lar=1/(1/la1r+1/la2r);
gar=real_para24(3);
vr=real_para24(4);

t1=real_para1(8);
t2=real_para2(8);
t3=real_para3(8);
t4=real_para4(8);
t5=real_para5(8);
t6=real_para6(8);
t7=real_para7(8);
t8=real_para8(8);
t9=real_para9(8);
t10=real_para10(8);
t11=real_para11(8);
t12=real_para12(8);
t13=real_para13(8);
t14=real_para14(8);
t15=real_para15(8);
t16=real_para16(8);
t17=real_para17(8);
t18=real_para18(8);
t19=real_para19(8);
t20=real_para20(8);
t21=real_para21(8);
t22=real_para22(8);
t23=real_para23(8);
t24=real_para24(8);



%%%%%%%%��һ��
print1=[lar ,gar ,vr];
range1=['A',num2str(zushu+1),':C',num2str(zushu+1)];
xlswrite(filename,print1,1,range1)

xlswrite(filenameSmin,print1,1,range1)


la_e_moment=[];
ga_e_moment=[];
v_e_moment=[];
ree_la_moment=[];
ree_ga_moment=[];
ree_v_moment=[];


Smin_moment=[];
moment_time=[];


for i=1:100
    % lain=data24(1,i);
    % gain=data24(2,i);
    % vin=4999./(data24(3,i)-1)-1;%���Ʒ�Χ

    lain=1/(1/data24(1,i)+1/data24(2,i));
    gain=data24(5,i);
    vin=4999./(data24(6,i)-1)-1;%���Ʒ�Χ


%% ��С���˷�
optims.MaxIter = 100000;
optims.MaxFunEvals = 100000;

tic
b0=[log(lain)  log(gain)  log(vin)];
[bmin0, Smin0] = fminsearch(@S4fun_pm4_nascentRNA_1,b0); % ��������������С����
toc

la_e_moment=[la_e_moment exp(bmin0(1))];
ga_e_moment=[ga_e_moment exp(bmin0(2))];
v_e_moment=[v_e_moment 1+4999./(exp(bmin0(3))+1)];
ree_la_moment=[ree_la_moment (exp(bmin0(1))-lar)/lar];
ree_ga_moment=[ree_ga_moment (exp(bmin0(2))-gar)/gar];
ree_v_moment=[ree_v_moment (1+4999./(exp(bmin0(3))+1)-vr)/vr];

Smin_moment=[Smin_moment Smin0];
moment_time=[moment_time toc];

end


% printall=[print2,print3,print4,print5,print6,print7,print8,print9,print10,print11,print12,print13,print14,print15,print16,print17,print18,print19,print20,print21,...
%     print22,print23,print24,print25,print26,print27,print28,print29,print30,print31,print32,print33,print34,print35,print36,print37,print38,print39,print40,print41,...
%     print42,print43,print44,print45,print46,print47,print48,print49,print50,print51,print52,print53,print54,print55,print56,print57,print58,print59,print60,print61,...
%     print62,print63,print64,print65,print66,print67,print68,print69,print70,print71,print72,print73,print74,print75,print76,print77,print78,print79,print80,print81,...
%     print82,print83,print84,print85,print86,print87,print88,print89,print90,print91,print92,print93,print94,print95,print96,print97,print98,print99,print100,print101];
% 


print2=[1,la_e_moment(1) ,ga_e_moment(1), v_e_moment(1), 0, ree_la_moment(1), ree_ga_moment(1), ree_v_moment(1),Smin_moment(1), moment_time(1)];
print3=[2,la_e_moment(2) ,ga_e_moment(2), v_e_moment(2), 0 ,ree_la_moment(2), ree_ga_moment(2), ree_v_moment(2),Smin_moment(2), moment_time(2)];
print4=[3, la_e_moment(3), ga_e_moment(3), v_e_moment(3), 0, ree_la_moment(3), ree_ga_moment(3), ree_v_moment(3),Smin_moment(3), moment_time(3)];
print5=[4 ,la_e_moment(4), ga_e_moment(4), v_e_moment(4), 0, ree_la_moment(4), ree_ga_moment(4), ree_v_moment(4),Smin_moment(4), moment_time(4)];
print6=[5 ,la_e_moment(5), ga_e_moment(5), v_e_moment(5), 0, ree_la_moment(5), ree_ga_moment(5), ree_v_moment(5),Smin_moment(5), moment_time(5)];
print7=[6 ,la_e_moment(6), ga_e_moment(6), v_e_moment(6), 0, ree_la_moment(6), ree_ga_moment(6), ree_v_moment(6),Smin_moment(6), moment_time(6)];
print8=[7 ,la_e_moment(7), ga_e_moment(7), v_e_moment(7), 0, ree_la_moment(7), ree_ga_moment(7), ree_v_moment(7),Smin_moment(7), moment_time(7)];
print9=[8 ,la_e_moment(8), ga_e_moment(8), v_e_moment(8), 0, ree_la_moment(8), ree_ga_moment(8), ree_v_moment(8),Smin_moment(8), moment_time(8)];
print10=[9, la_e_moment(9), ga_e_moment(9), v_e_moment(9),0, ree_la_moment(9), ree_ga_moment(9), ree_v_moment(9),Smin_moment(9), moment_time(9)];
print11=[10, la_e_moment(10), ga_e_moment(10), v_e_moment(10),0, ree_la_moment(10), ree_ga_moment(10), ree_v_moment(10), Smin_moment(10),moment_time(10)];
print12=[11,la_e_moment(11) ,ga_e_moment(11), v_e_moment(11), 0, ree_la_moment(11), ree_ga_moment(11), ree_v_moment(11),Smin_moment(11), moment_time(11)];
print13=[12,la_e_moment(12) ,ga_e_moment(12), v_e_moment(12), 0 ,ree_la_moment(12), ree_ga_moment(12), ree_v_moment(12), Smin_moment(12),moment_time(12)];
print14=[13, la_e_moment(13), ga_e_moment(13), v_e_moment(13), 0, ree_la_moment(13), ree_ga_moment(13), ree_v_moment(13),Smin_moment(13), moment_time(13)];
print15=[14 ,la_e_moment(14), ga_e_moment(14), v_e_moment(14), 0, ree_la_moment(14), ree_ga_moment(14), ree_v_moment(14), Smin_moment(14),moment_time(14)];
print16=[15 ,la_e_moment(15), ga_e_moment(15), v_e_moment(15), 0, ree_la_moment(15), ree_ga_moment(15), ree_v_moment(15), Smin_moment(15),moment_time(15)];
print17=[16 ,la_e_moment(16), ga_e_moment(16), v_e_moment(16), 0, ree_la_moment(16), ree_ga_moment(16), ree_v_moment(16), Smin_moment(16),moment_time(16)];
print18=[17 ,la_e_moment(17), ga_e_moment(17), v_e_moment(17), 0, ree_la_moment(17), ree_ga_moment(17), ree_v_moment(17), Smin_moment(17),moment_time(17)];
print19=[18 ,la_e_moment(18), ga_e_moment(18), v_e_moment(18), 0, ree_la_moment(18), ree_ga_moment(18), ree_v_moment(18),Smin_moment(18), moment_time(18)];
print20=[19, la_e_moment(19), ga_e_moment(19), v_e_moment(19),0, ree_la_moment(19), ree_ga_moment(19), ree_v_moment(19),Smin_moment(19), moment_time(19)];
print21=[20, la_e_moment(20), ga_e_moment(20), v_e_moment(20),0, ree_la_moment(20), ree_ga_moment(20), ree_v_moment(20),Smin_moment(20), moment_time(20)];
print22=[21,la_e_moment(21) ,ga_e_moment(21), v_e_moment(21), 0, ree_la_moment(21), ree_ga_moment(21), ree_v_moment(21),Smin_moment(21), moment_time(21)];
print23=[22,la_e_moment(22) ,ga_e_moment(22), v_e_moment(22), 0 ,ree_la_moment(22), ree_ga_moment(22), ree_v_moment(22),Smin_moment(22), moment_time(22)];
print24=[23, la_e_moment(23), ga_e_moment(23), v_e_moment(23), 0, ree_la_moment(23), ree_ga_moment(23), ree_v_moment(23),Smin_moment(23), moment_time(23)];
print25=[24 ,la_e_moment(24), ga_e_moment(24), v_e_moment(24), 0, ree_la_moment(24), ree_ga_moment(24), ree_v_moment(24),Smin_moment(24), moment_time(24)];
print26=[25 ,la_e_moment(25), ga_e_moment(25), v_e_moment(25), 0, ree_la_moment(25), ree_ga_moment(25), ree_v_moment(25),Smin_moment(25), moment_time(25)];
print27=[26 ,la_e_moment(26), ga_e_moment(26), v_e_moment(26), 0, ree_la_moment(26), ree_ga_moment(26), ree_v_moment(26),Smin_moment(26), moment_time(26)];
print28=[27 ,la_e_moment(27), ga_e_moment(27), v_e_moment(27), 0, ree_la_moment(27), ree_ga_moment(27), ree_v_moment(27),Smin_moment(27), moment_time(27)];
print29=[28 ,la_e_moment(28), ga_e_moment(28), v_e_moment(28), 0, ree_la_moment(28), ree_ga_moment(28), ree_v_moment(28),Smin_moment(28), moment_time(28)];
print30=[29, la_e_moment(29), ga_e_moment(29), v_e_moment(29),0, ree_la_moment(29), ree_ga_moment(29), ree_v_moment(29),Smin_moment(29), moment_time(29)];
print31=[30, la_e_moment(30), ga_e_moment(30), v_e_moment(30),0, ree_la_moment(30), ree_ga_moment(30), ree_v_moment(30), Smin_moment(30),moment_time(30)];
print32=[31,la_e_moment(31) ,ga_e_moment(31), v_e_moment(31), 0, ree_la_moment(31), ree_ga_moment(31), ree_v_moment(31),Smin_moment(31), moment_time(31)];
print33=[32,la_e_moment(32) ,ga_e_moment(32), v_e_moment(32), 0 ,ree_la_moment(32), ree_ga_moment(32), ree_v_moment(32), Smin_moment(32),moment_time(32)];
print34=[33, la_e_moment(33), ga_e_moment(33), v_e_moment(33), 0, ree_la_moment(33), ree_ga_moment(33), ree_v_moment(33),Smin_moment(33), moment_time(33)];
print35=[34 ,la_e_moment(34), ga_e_moment(34), v_e_moment(34), 0, ree_la_moment(34), ree_ga_moment(34), ree_v_moment(34), Smin_moment(34),moment_time(34)];
print36=[35 ,la_e_moment(35), ga_e_moment(35), v_e_moment(35), 0, ree_la_moment(35), ree_ga_moment(35), ree_v_moment(35), Smin_moment(35),moment_time(35)];
print37=[36 ,la_e_moment(36), ga_e_moment(36), v_e_moment(36), 0, ree_la_moment(36), ree_ga_moment(36), ree_v_moment(36), Smin_moment(36),moment_time(36)];
print38=[37 ,la_e_moment(37), ga_e_moment(37), v_e_moment(37), 0, ree_la_moment(37), ree_ga_moment(37), ree_v_moment(37), Smin_moment(37),moment_time(37)];
print39=[38 ,la_e_moment(38), ga_e_moment(38), v_e_moment(38), 0, ree_la_moment(38), ree_ga_moment(38), ree_v_moment(38),Smin_moment(38), moment_time(38)];
print40=[39, la_e_moment(39), ga_e_moment(39), v_e_moment(39),0, ree_la_moment(39), ree_ga_moment(39), ree_v_moment(39),Smin_moment(39), moment_time(39)];
print41=[40, la_e_moment(40), ga_e_moment(40), v_e_moment(40),0, ree_la_moment(40), ree_ga_moment(40), ree_v_moment(40),Smin_moment(40), moment_time(40)];
print42=[41,la_e_moment(41) ,ga_e_moment(41), v_e_moment(41), 0, ree_la_moment(41), ree_ga_moment(41), ree_v_moment(41),Smin_moment(41), moment_time(41)];
print43=[42,la_e_moment(42) ,ga_e_moment(42), v_e_moment(42), 0 ,ree_la_moment(42), ree_ga_moment(42), ree_v_moment(42),Smin_moment(42), moment_time(42)];
print44=[43, la_e_moment(43), ga_e_moment(43), v_e_moment(43), 0, ree_la_moment(43), ree_ga_moment(43), ree_v_moment(43),Smin_moment(43), moment_time(43)];
print45=[44 ,la_e_moment(44), ga_e_moment(44), v_e_moment(44), 0, ree_la_moment(44), ree_ga_moment(44), ree_v_moment(44),Smin_moment(44), moment_time(44)];
print46=[45 ,la_e_moment(45), ga_e_moment(45), v_e_moment(45), 0, ree_la_moment(45), ree_ga_moment(45), ree_v_moment(45),Smin_moment(45), moment_time(45)];
print47=[46 ,la_e_moment(46), ga_e_moment(46), v_e_moment(46), 0, ree_la_moment(46), ree_ga_moment(46), ree_v_moment(46),Smin_moment(46), moment_time(46)];
print48=[47 ,la_e_moment(47), ga_e_moment(47), v_e_moment(47), 0, ree_la_moment(47), ree_ga_moment(47), ree_v_moment(47),Smin_moment(47), moment_time(47)];
print49=[48 ,la_e_moment(48), ga_e_moment(48), v_e_moment(48), 0, ree_la_moment(48), ree_ga_moment(48), ree_v_moment(48),Smin_moment(48), moment_time(48)];
print50=[49, la_e_moment(49), ga_e_moment(49), v_e_moment(49),0, ree_la_moment(49), ree_ga_moment(49), ree_v_moment(49),Smin_moment(49), moment_time(49)];
print51=[50, la_e_moment(50), ga_e_moment(50), v_e_moment(50),0, ree_la_moment(50), ree_ga_moment(50), ree_v_moment(50), Smin_moment(50),moment_time(50)];

print52=[51,la_e_moment(51) ,ga_e_moment(51), v_e_moment(51), 0, ree_la_moment(51), ree_ga_moment(51), ree_v_moment(51),Smin_moment(51), moment_time(51)];
print53=[52,la_e_moment(52) ,ga_e_moment(52), v_e_moment(52), 0 ,ree_la_moment(52), ree_ga_moment(52), ree_v_moment(52),Smin_moment(52), moment_time(52)];
print54=[53, la_e_moment(53), ga_e_moment(53), v_e_moment(53), 0, ree_la_moment(53), ree_ga_moment(53), ree_v_moment(53),Smin_moment(53), moment_time(53)];
print55=[54 ,la_e_moment(54), ga_e_moment(54), v_e_moment(54), 0, ree_la_moment(54), ree_ga_moment(54), ree_v_moment(54),Smin_moment(54), moment_time(54)];
print56=[55 ,la_e_moment(55), ga_e_moment(55), v_e_moment(55), 0, ree_la_moment(55), ree_ga_moment(55), ree_v_moment(55),Smin_moment(55), moment_time(55)];
print57=[56 ,la_e_moment(56), ga_e_moment(56), v_e_moment(56), 0, ree_la_moment(56), ree_ga_moment(56), ree_v_moment(56),Smin_moment(56), moment_time(56)];
print58=[57 ,la_e_moment(57), ga_e_moment(57), v_e_moment(57), 0, ree_la_moment(57), ree_ga_moment(57), ree_v_moment(57),Smin_moment(57), moment_time(57)];
print59=[58 ,la_e_moment(58), ga_e_moment(58), v_e_moment(58), 0, ree_la_moment(58), ree_ga_moment(58), ree_v_moment(58),Smin_moment(58), moment_time(58)];
print60=[59, la_e_moment(59), ga_e_moment(59), v_e_moment(59),0, ree_la_moment(59), ree_ga_moment(59), ree_v_moment(59),Smin_moment(59), moment_time(59)];
print61=[60, la_e_moment(60), ga_e_moment(60), v_e_moment(60),0, ree_la_moment(60), ree_ga_moment(60), ree_v_moment(60), Smin_moment(60),moment_time(60)];
print62=[61,la_e_moment(61) ,ga_e_moment(61), v_e_moment(61), 0, ree_la_moment(61), ree_ga_moment(61), ree_v_moment(61),Smin_moment(61), moment_time(61)];
print63=[62,la_e_moment(62) ,ga_e_moment(62), v_e_moment(62), 0 ,ree_la_moment(62), ree_ga_moment(62), ree_v_moment(62),Smin_moment(62), moment_time(62)];
print64=[63, la_e_moment(63), ga_e_moment(63), v_e_moment(63), 0, ree_la_moment(63), ree_ga_moment(63), ree_v_moment(63),Smin_moment(63), moment_time(63)];
print65=[64 ,la_e_moment(64), ga_e_moment(64), v_e_moment(64), 0, ree_la_moment(64), ree_ga_moment(64), ree_v_moment(64),Smin_moment(64), moment_time(64)];
print66=[65 ,la_e_moment(65), ga_e_moment(65), v_e_moment(65), 0, ree_la_moment(65), ree_ga_moment(65), ree_v_moment(65),Smin_moment(65), moment_time(65)];
print67=[66 ,la_e_moment(66), ga_e_moment(66), v_e_moment(66), 0, ree_la_moment(66), ree_ga_moment(66), ree_v_moment(66),Smin_moment(66), moment_time(66)];
print68=[67 ,la_e_moment(67), ga_e_moment(67), v_e_moment(67), 0, ree_la_moment(67), ree_ga_moment(67), ree_v_moment(67),Smin_moment(67), moment_time(67)];
print69=[68 ,la_e_moment(68), ga_e_moment(68), v_e_moment(68), 0, ree_la_moment(68), ree_ga_moment(68), ree_v_moment(68),Smin_moment(68), moment_time(68)];
print70=[69, la_e_moment(69), ga_e_moment(69), v_e_moment(69),0, ree_la_moment(69), ree_ga_moment(69), ree_v_moment(69),Smin_moment(69), moment_time(69)];
print71=[70, la_e_moment(70), ga_e_moment(70), v_e_moment(70),0, ree_la_moment(70), ree_ga_moment(70), ree_v_moment(70), Smin_moment(70),moment_time(70)];
print72=[71,la_e_moment(71) ,ga_e_moment(71), v_e_moment(71), 0, ree_la_moment(71), ree_ga_moment(71), ree_v_moment(71),Smin_moment(71), moment_time(71)];
print73=[72,la_e_moment(72) ,ga_e_moment(72), v_e_moment(72), 0 ,ree_la_moment(72), ree_ga_moment(72), ree_v_moment(72),Smin_moment(72), moment_time(72)];
print74=[73, la_e_moment(73), ga_e_moment(73), v_e_moment(73), 0, ree_la_moment(73), ree_ga_moment(73), ree_v_moment(73),Smin_moment(73), moment_time(73)];
print75=[74 ,la_e_moment(74), ga_e_moment(74), v_e_moment(74), 0, ree_la_moment(74), ree_ga_moment(74), ree_v_moment(74),Smin_moment(74), moment_time(74)];
print76=[75 ,la_e_moment(75), ga_e_moment(75), v_e_moment(75), 0, ree_la_moment(75), ree_ga_moment(75), ree_v_moment(75),Smin_moment(75), moment_time(75)];
print77=[76 ,la_e_moment(76), ga_e_moment(76), v_e_moment(76), 0, ree_la_moment(76), ree_ga_moment(76), ree_v_moment(76),Smin_moment(76), moment_time(76)];
print78=[77 ,la_e_moment(77), ga_e_moment(77), v_e_moment(77), 0, ree_la_moment(77), ree_ga_moment(77), ree_v_moment(77),Smin_moment(77), moment_time(77)];
print79=[78 ,la_e_moment(78), ga_e_moment(78), v_e_moment(78), 0, ree_la_moment(78), ree_ga_moment(78), ree_v_moment(78),Smin_moment(78), moment_time(78)];
print80=[79, la_e_moment(79), ga_e_moment(79), v_e_moment(79),0, ree_la_moment(79), ree_ga_moment(79), ree_v_moment(79),Smin_moment(79), moment_time(79)];
print81=[80, la_e_moment(80), ga_e_moment(80), v_e_moment(80),0, ree_la_moment(80), ree_ga_moment(80), ree_v_moment(80), Smin_moment(80),moment_time(80)];
print82=[81,la_e_moment(81) ,ga_e_moment(81), v_e_moment(81), 0, ree_la_moment(81), ree_ga_moment(81), ree_v_moment(81),Smin_moment(81), moment_time(81)];
print83=[82,la_e_moment(82) ,ga_e_moment(82), v_e_moment(82), 0 ,ree_la_moment(82), ree_ga_moment(82), ree_v_moment(82),Smin_moment(82), moment_time(82)];
print84=[83, la_e_moment(83), ga_e_moment(83), v_e_moment(83), 0, ree_la_moment(83), ree_ga_moment(83), ree_v_moment(83),Smin_moment(83), moment_time(83)];
print85=[84 ,la_e_moment(84), ga_e_moment(84), v_e_moment(84), 0, ree_la_moment(84), ree_ga_moment(84), ree_v_moment(84),Smin_moment(84), moment_time(84)];
print86=[85 ,la_e_moment(85), ga_e_moment(85), v_e_moment(85), 0, ree_la_moment(85), ree_ga_moment(85), ree_v_moment(85),Smin_moment(85), moment_time(85)];
print87=[86 ,la_e_moment(86), ga_e_moment(86), v_e_moment(86), 0, ree_la_moment(86), ree_ga_moment(86), ree_v_moment(86),Smin_moment(86), moment_time(86)];
print88=[87 ,la_e_moment(87), ga_e_moment(87), v_e_moment(87), 0, ree_la_moment(87), ree_ga_moment(87), ree_v_moment(87),Smin_moment(87), moment_time(87)];
print89=[88 ,la_e_moment(88), ga_e_moment(88), v_e_moment(88), 0, ree_la_moment(88), ree_ga_moment(88), ree_v_moment(88),Smin_moment(88), moment_time(88)];
print90=[89, la_e_moment(89), ga_e_moment(89), v_e_moment(89),0, ree_la_moment(89), ree_ga_moment(89), ree_v_moment(89),Smin_moment(89), moment_time(89)];
print91=[90, la_e_moment(90), ga_e_moment(90), v_e_moment(90),0, ree_la_moment(90), ree_ga_moment(90), ree_v_moment(90), Smin_moment(90),moment_time(90)];
print92=[91,la_e_moment(91) ,ga_e_moment(91), v_e_moment(91), 0, ree_la_moment(91), ree_ga_moment(91), ree_v_moment(91),Smin_moment(91), moment_time(91)];
print93=[92,la_e_moment(92) ,ga_e_moment(92), v_e_moment(92), 0 ,ree_la_moment(92), ree_ga_moment(92), ree_v_moment(92),Smin_moment(92), moment_time(92)];
print94=[93, la_e_moment(93), ga_e_moment(93), v_e_moment(93), 0, ree_la_moment(93), ree_ga_moment(93), ree_v_moment(93),Smin_moment(93), moment_time(93)];
print95=[94 ,la_e_moment(94), ga_e_moment(94), v_e_moment(94), 0, ree_la_moment(94), ree_ga_moment(94), ree_v_moment(94),Smin_moment(94), moment_time(94)];
print96=[95 ,la_e_moment(95), ga_e_moment(95), v_e_moment(95), 0, ree_la_moment(95), ree_ga_moment(95), ree_v_moment(95),Smin_moment(95), moment_time(95)];
print97=[96 ,la_e_moment(96), ga_e_moment(96), v_e_moment(96), 0, ree_la_moment(96), ree_ga_moment(96), ree_v_moment(96),Smin_moment(96), moment_time(96)];
print98=[97 ,la_e_moment(97), ga_e_moment(97), v_e_moment(97), 0, ree_la_moment(97), ree_ga_moment(97), ree_v_moment(97),Smin_moment(97), moment_time(97)];
print99=[98 ,la_e_moment(98), ga_e_moment(98), v_e_moment(98), 0, ree_la_moment(98), ree_ga_moment(98), ree_v_moment(98),Smin_moment(98), moment_time(98)];
print100=[99, la_e_moment(99), ga_e_moment(99), v_e_moment(99),0, ree_la_moment(99), ree_ga_moment(99), ree_v_moment(99),Smin_moment(99), moment_time(99)];
print101=[100, la_e_moment(100), ga_e_moment(100), v_e_moment(100),0, ree_la_moment(100), ree_ga_moment(100), ree_v_moment(100), Smin_moment(100),moment_time(100)];


printall=[print2,print3,print4,print5,print6,print7,print8,print9,print10,print11,print12,print13,print14,print15,print16,print17,print18,print19,print20,print21,...
    print22,print23,print24,print25,print26,print27,print28,print29,print30,print31,print32,print33,print34,print35,print36,print37,print38,print39,print40,print41,...
    print42,print43,print44,print45,print46,print47,print48,print49,print50,print51,print52,print53,print54,print55,print56,print57,print58,print59,print60,print61,...
    print62,print63,print64,print65,print66,print67,print68,print69,print70,print71,print72,print73,print74,print75,print76,print77,print78,print79,print80,print81,...
    print82,print83,print84,print85,print86,print87,print88,print89,print90,print91,print92,print93,print94,print95,print96,print97,print98,print99,print100,print101];



range=['D',num2str(zushu+1)];
xlswrite(filename,printall,1,range)

Smin_moment_min=min(Smin_moment);
Smin_moment_min_loction=find(Smin_moment==Smin_moment_min);
la_moment=la_e_moment(Smin_moment_min_loction);
ga_moment=ga_e_moment(Smin_moment_min_loction);
v_moment=v_e_moment(Smin_moment_min_loction);
Ree_la_moment=ree_la_moment(Smin_moment_min_loction);
Ree_ga_moment=ree_ga_moment(Smin_moment_min_loction);
Ree_v_moment=ree_v_moment(Smin_moment_min_loction);
moment_time_sum=sum(moment_time);


printSmin1=[la_moment ga_moment v_moment];
printSmin2=[Ree_la_moment Ree_ga_moment Ree_v_moment Smin_moment_min moment_time_sum];

rangeSmin1=['E',num2str(zushu+1),':G',num2str(zushu+1)];
rangeSmin2=['I',num2str(zushu+1),':M',num2str(zushu+1)];



xlswrite(filenameSmin,printSmin1,1,rangeSmin1)
xlswrite(filenameSmin,printSmin2,1,rangeSmin2)


zushu
clear global

end
end