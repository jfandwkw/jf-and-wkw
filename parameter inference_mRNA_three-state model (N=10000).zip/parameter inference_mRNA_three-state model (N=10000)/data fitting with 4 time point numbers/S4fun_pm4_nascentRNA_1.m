function S4 = S4fun_pm4_nascentRNA_1(bb4)
%%%% ��С����

global  t6  t12  t18  t24 m second fanodata %%����

T=[t6 t12 t18 t24];

% Initialize arrays to store results
xmean = zeros(1, length(T));
u2 = zeros(1, length(T));
xfano = zeros(1, length(T));

b4 = [exp(bb4(1)), exp(bb4(2)), exp(bb4(3)), 1 + 4999./(exp(bb4(4)) + 1)];

kon_1 = b4(1);
kon_2 = b4(2);
koff = b4(3);
kb = b4(4);
delta = 1;

Delta = (kon_1+kon_2+koff)^2 - 4*((kon_1+kon_2)*koff + kon_1*kon_2);
alpha = (1/2)*(kon_1+kon_2+koff+sqrt(Delta));
beta = (1/2)*(kon_1+kon_2+koff-sqrt(Delta));

for t = 1:length(T)
    current_T = T(t); % Get the current time point
    
    % ����m(t)�ĸ�������
    term1 = (kon_1 * kon_2 * kb) / (alpha * beta * delta);
    kbmerator2 = kon_1 * kon_2 * kb;
    denominator2 = alpha * (beta - alpha) * (delta - alpha);
    term2 = (kbmerator2 / denominator2) * exp(-alpha * current_T);
    kbmerator3 = kon_1 * kon_2 * kb;
    denominator3 = beta * (alpha - beta) * (delta - beta);
    term3 = (kbmerator3 / denominator3) * exp(-beta * current_T);
    kbmerator4 = kon_1 * kon_2 * kb;
    denominator4 = delta * (alpha - delta) * (beta - delta);
    term4 = (kbmerator4 / denominator4) * exp(-delta * current_T);

    % ������ս��
    xmean(t) = term1 - term2 - term3 - term4;
    
    % ����u2(t)��ϵ��
    % b0
    kbmerator_b0 = kb*delta*(delta+alpha)*(delta+beta) + kb^2*(delta+kon_1)*(delta+kon_2);
    denominator_b0 = alpha*beta*delta^2*(delta+alpha)*(delta+beta);
    b0 = (kbmerator_b0 / denominator_b0) * kon_1*kon_2;
    % b_alpha
    kbmerator_balpha = kb*delta*(2*delta-alpha)*(delta+beta-alpha) + 2*kb^2*(delta+kon_1-alpha)*(delta+kon_2-alpha);
    denominator_balpha = alpha*delta*(beta-alpha)*(delta-alpha)*(2*delta-alpha)*(delta+beta-alpha);
    balpha = -(kbmerator_balpha / denominator_balpha) * kon_1 * kon_2;
    % b_beta
    kbmerator_bbeta = kb*delta*(2*delta-beta)*(delta+alpha-beta) + 2*kb^2*(delta+kon_1-beta)*(delta+kon_2-beta);
    denominator_bbeta = beta*delta*(alpha-beta)*(delta-beta)*(2*delta-beta)*(delta+alpha-beta);
    bbeta = -(kbmerator_bbeta / denominator_bbeta) * kon_1 * kon_2;
    % b_delta
    kbmerator_bdelta = kb*delta*alpha*beta + 2*kb^2*kon_1*kon_2;
    denominator_bdelta = alpha*beta*delta^2*(alpha-delta)*(beta-delta);
    bdelta = -(kbmerator_bdelta / denominator_bdelta) * kon_1 * kon_2;
    % b_2delta
    kbmerator_b2delta = kb^2*(kon_1-delta)*(kon_2-delta);
    denominator_b2delta = delta^2*(alpha-2*delta)*(beta-2*delta)*(alpha-delta)*(beta-delta);
    b2delta = (kbmerator_b2delta / denominator_b2delta) * kon_1 * kon_2;
    % b_delta_alpha
    kbmerator_bda = 2*kb^2*(kon_1-alpha)*(kon_2-alpha);
    denominator_bda = delta*alpha*(delta+alpha)*(beta-delta-alpha)*(delta-alpha)*(beta-alpha);
    bdelta_alpha = -(kbmerator_bda / denominator_bda) * kon_1 * kon_2;
    % b_delta_beta
    kbmerator_bdb = 2*kb^2*(kon_1-beta)*(kon_2-beta);
    denominator_bdb = delta*beta*(delta+beta)*(alpha-delta-beta)*(delta-beta)*(alpha-beta);
    bdelta_beta = -(kbmerator_bdb / denominator_bdb) * kon_1 * kon_2;
    
    % ������ս��
    u2(t) = b0 + ...
            balpha * exp(-alpha * current_T) + ...
            bbeta * exp(-beta * current_T) + ...
            bdelta * exp(-delta * current_T) + ...
            b2delta * exp(-2 * delta * current_T) + ...
            bdelta_alpha * exp(-(delta + alpha) * current_T) + ...
            bdelta_beta * exp(-(delta + beta) * current_T);
    
    xfano(t) = (u2(t) - xmean(t)^2) / xmean(t);
end

%% Calculate objective function
Smean = 0;
for i = 1:length(m)
    Smean = Smean + (xmean(i)-m(i))^2/m(i)^2;
end

Su2 = 0;
for i = 1:length(second)
    Su2 = Su2 + (u2(i)-second(i))^2/second(i)^2;
end

Sfano = 0;
for i = 1:length(fanodata)
    Sfano = Sfano + (xfano(i)-fanodata(i))^2/fanodata(i)^2;
end

S4 = Smean + Su2 + Sfano;
end
