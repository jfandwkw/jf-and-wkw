j = 68;         % 第j列数据
TT = 30;        % 最大时间
T = 1;         % 转换时间点
t = 0:0.001:TT;

% 读取真实参数（crosstalking模型参数）
data = xlsread('N10000_twostate_t24.xlsx');
la1 = data(1, j);
la2 = data(2, j);
q1 = data(3, j);
q2 = 1 - q1;
k_10 = data(5, j);
r = data(6, j);
delta = 1;

% -------- 第一组参数（真实参数模型） --------
odefun1 = @(t,y)[
    q1*k_10*y(3)-la1*y(1);
    q2*k_10*y(3)-la2*y(2);
    la1*y(1)+la2*y(2)-k_10*y(3);
    r*y(3)-delta*y(4);
    -(la1+delta)*y(5)+q1*k_10*y(7);
    -(la2+delta)*y(6)+q2*k_10*y(7);
    -(k_10+delta)*y(7)+la1*y(5)+la2*y(6)+r*y(3);
    -2*delta*y(8)+delta*y(4)+r*y(3)+2*r*y(7)
];
y00_1 = [q1, q2, 0, 0, 0, 0, 0, 0];
[t1, y1] = ode45(odefun1, [0 TT], y00_1, odeset('reltol',1e-6,'abstol',1e-8));
M1 = y1(:, 4);  % mean for real parameter

% -------- 第二组参数（估计参数模型） --------
data1 = xlsread('twostate_fitmethod_N10000_Smin.xlsx');
k_01 = data1(j, 5);
k_10 = data1(j, 6);
r = data1(j, 7);

odefun2 = @(t,y)[
    k_10*y(2)-k_01*y(1);
    k_01*y(1)-k_10*y(2);
    r*y(2)-delta*y(3);
    -(k_01+delta)*y(4)+k_10*y(5);
    -(k_10+delta)*y(5)+k_01*y(4)+r*y(2);
    -2*delta*y(6)+delta*y(3)+r*y(2)+2*r*y(5)
];
y00_2 = [1, 0, 0, 0, 0, 0];
[t2, y2] = ode45(odefun2, [0 TT], y00_2, odeset('reltol',1e-6,'abstol',1e-8));
M2 = y2(:, 3);  % mean for fitted parameter

% -------- 读取实验数据点 --------
x_exp = zeros(1, 24);  % 时间（第10行）
y_exp = zeros(1, 24);  % 均值（第7行）
for t_idx = 2:2:24
    filename = sprintf('N10000_twostate_t%d.xlsx', t_idx);
    data_exp = readmatrix(filename);
    x_exp(t_idx) = data_exp(10, j);
    y_exp(t_idx) = data_exp(7, j);
end

% -------- 绘图 --------
figure;
plot(t1, M1, 'b-', 'LineWidth', 2); hold on;
plot(t2, M2, 'r--', 'LineWidth', 2);
plot(x_exp, y_exp, 'ko', 'LineWidth', 1.5, 'MarkerSize', 6);

legend('真实参数', '估计参数', '实验数据点');
xlabel('时间 t');
ylabel('Mean');
title(sprintf('Crosstalking Model 第 %d 组 Mean 拟合对比及数据点', j));
grid on;
